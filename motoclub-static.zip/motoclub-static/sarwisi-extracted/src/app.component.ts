import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PageContentService } from './services/page-content.service';
import { PageBlock } from './models/streamfield.model';
import { HeaderComponent } from './components/header.component';
import { FooterComponent } from './components/footer.component';
import { HeroBlockComponent } from './components/hero-block.component';
import { FeaturesBlockComponent } from './components/features-block.component';
import { ContentBlockComponent } from './components/content-block.component';
import { TestimonialsBlockComponent } from './components/testimonials-block.component';
import { CtaBlockComponent } from './components/cta-block.component';
import { TimelineBlockComponent } from './components/timeline-block.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    HeaderComponent,
    FooterComponent,
    HeroBlockComponent,
    FeaturesBlockComponent,
    ContentBlockComponent,
    TestimonialsBlockComponent,
    CtaBlockComponent,
    TimelineBlockComponent
  ],
  templateUrl: './app.component.html',
  styleUrls: []
})
export class AppComponent {
  private pageService = inject(PageContentService);
  
  // Signal to hold our list of blocks (StreamField data)
  blocks = signal<PageBlock[]>([]);

  constructor() {
    this.pageService.getPageData().subscribe((data) => {
      this.blocks.set(data);
    });
  }
}
