import { Directive, ElementRef, inject, AfterViewInit, OnDestroy, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appScrollAnimation]',
  standalone: true
})
export class ScrollAnimationDirective implements AfterViewInit, OnDestroy {
  private el = inject(ElementRef);
  private renderer = inject(Renderer2);
  private observer: IntersectionObserver | undefined;

  ngAfterViewInit() {
    this.observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          this.renderer.addClass(this.el.nativeElement, 'is-visible');
          this.observer?.unobserve(this.el.nativeElement);
        }
      });
    }, { 
      threshold: 0.15, // Trigger when 15% visible
      rootMargin: '0px 0px -50px 0px' 
    });

    this.renderer.addClass(this.el.nativeElement, 'reveal-on-scroll');
    this.observer.observe(this.el.nativeElement);
  }

  ngOnDestroy() {
    this.observer?.disconnect();
  }
}