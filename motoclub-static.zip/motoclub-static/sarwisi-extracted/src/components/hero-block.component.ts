import { Component, input, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { HeroData } from '../models/streamfield.model';
import { ScrollAnimationDirective } from '../directives/scroll-animation.directive';

@Component({
  selector: 'app-hero-block',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, NgOptimizedImage, ScrollAnimationDirective],
  template: `
    <div class="relative bg-gray-900 overflow-hidden h-[600px] flex items-center group">
       <!-- Background Image Overlay with Animation -->
      <div class="absolute inset-0 overflow-hidden">
        @if (data().backgroundImage) {
          <img [ngSrc]="data().backgroundImage!" fill priority alt="Hero Background" class="object-cover opacity-40 animate-slow-zoom">
        } @else {
          <div class="w-full h-full bg-gradient-to-r from-blue-900 to-indigo-900 opacity-90"></div>
        }
        <div class="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent"></div>
      </div>

      <!-- Content Container -->
      <div class="relative container mx-auto px-6 text-center lg:text-left" appScrollAnimation>
        <div class="lg:w-2/3">
          <h1 class="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight tracking-tight drop-shadow-md">
            {{ data().title }}
          </h1>
          <p class="text-xl text-gray-200 mb-8 font-light max-w-2xl drop-shadow-sm">
            {{ data().subtitle }}
          </p>
          <a [href]="data().ctaLink" 
             class="inline-block bg-blue-600 hover:bg-blue-700 text-white font-semibold py-4 px-8 rounded-full transition-all transform hover:scale-105 hover:shadow-2xl animate-pulse-glow">
            {{ data().ctaText }}
            <i class="fas fa-arrow-right ml-2 group-hover:translate-x-1 transition-transform"></i>
          </a>
        </div>
      </div>
    </div>
  `
})
export class HeroBlockComponent {
  data = input.required<HeroData>();
}