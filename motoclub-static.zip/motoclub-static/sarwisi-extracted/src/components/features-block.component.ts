import { Component, input, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FeaturesData } from '../models/streamfield.model';
import { ScrollAnimationDirective } from '../directives/scroll-animation.directive';

@Component({
  selector: 'app-features-block',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ScrollAnimationDirective],
  template: `
    <section class="py-20 bg-gray-50">
      <div class="container mx-auto px-6">
        <div class="text-center mb-16" appScrollAnimation>
          <h2 class="text-3xl font-bold text-gray-800 relative inline-block">
            {{ data().title }}
            <span class="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-16 h-1 bg-blue-500 rounded mt-2 block"></span>
          </h2>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          @for (item of data().items; track item.title) {
            <!-- Staggered animation using index delay -->
            <div class="bg-white p-8 rounded-xl shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100 group transform hover:-translate-y-2" 
                 appScrollAnimation 
                 [style.transition-delay.ms]="$index * 150">
              
              <!-- Icon Container with Tooltip -->
              <div class="relative w-14 h-14 bg-blue-100 rounded-lg flex items-center justify-center mb-6 group-hover:bg-blue-600 transition-colors duration-300 group/icon">
                <i [class]="'fas ' + item.icon + ' text-2xl text-blue-600 group-hover:text-white transition-colors duration-300'"></i>
                
                <!-- Tooltip -->
                <div class="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 bg-gray-900 text-white text-xs font-medium rounded opacity-0 group-hover/icon:opacity-100 transition-opacity duration-200 pointer-events-none whitespace-nowrap z-10 shadow-lg">
                  {{ item.title }}
                  <!-- Tooltip Arrow -->
                  <div class="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-gray-900"></div>
                </div>
              </div>
              
              <h3 class="text-xl font-bold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors">{{ item.title }}</h3>
              <p class="text-gray-600 leading-relaxed">{{ item.description }}</p>
            </div>
          }
        </div>
      </div>
    </section>
  `
})
export class FeaturesBlockComponent {
  data = input.required<FeaturesData>();
}