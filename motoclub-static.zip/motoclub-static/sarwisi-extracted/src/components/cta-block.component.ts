import { Component, input, computed, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CtaData } from '../models/streamfield.model';
import { ScrollAnimationDirective } from '../directives/scroll-animation.directive';

@Component({
  selector: 'app-cta-block',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ScrollAnimationDirective],
  template: `
    <section [class]="sectionClasses()">
      <div class="container mx-auto px-6 text-center" appScrollAnimation>
        <h2 class="text-3xl md:text-4xl font-bold mb-4">{{ data().title }}</h2>
        <p [class]="descClasses()">{{ data().description }}</p>
        <a [href]="data().buttonLink" 
           [class]="buttonClasses()">
           {{ data().buttonText }}
        </a>
      </div>
    </section>
  `
})
export class CtaBlockComponent {
  data = input.required<CtaData>();

  sectionClasses = computed(() => {
    return this.data().theme === 'dark' 
      ? 'py-20 bg-gray-900 text-white' 
      : 'py-20 bg-blue-600 text-white';
  });

  descClasses = computed(() => {
    return 'text-xl mb-8 opacity-90 max-w-2xl mx-auto';
  });

  buttonClasses = computed(() => {
    const baseClasses = 'inline-block font-bold py-3 px-8 rounded-lg transition-all transform hover:scale-105 shadow-lg';
    return this.data().theme === 'dark'
      ? `${baseClasses} bg-white text-gray-900 hover:bg-gray-100`
      : `${baseClasses} bg-white text-blue-600 hover:bg-blue-50 animate-pulse-glow`;
  });
}