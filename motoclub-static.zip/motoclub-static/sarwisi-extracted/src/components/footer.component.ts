import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  standalone: true,
  template: `
    <footer class="bg-gray-900 text-gray-300 py-12">
      <div class="container mx-auto px-6">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          
          <!-- Column 1 -->
          <div>
            <div class="flex items-center gap-2 mb-6">
              <div class="w-8 h-8 bg-blue-600 rounded flex items-center justify-center text-white font-bold">S</div>
              <span class="text-xl font-bold text-white">Sarwisi</span>
            </div>
            <p class="text-sm leading-relaxed mb-6">
              Soluzioni digitali innovative per far crescere il tuo business nel mondo moderno.
            </p>
            <div class="flex space-x-4">
              <a href="#" class="hover:text-white transition-colors"><i class="fab fa-facebook-f"></i></a>
              <a href="#" class="hover:text-white transition-colors"><i class="fab fa-twitter"></i></a>
              <a href="#" class="hover:text-white transition-colors"><i class="fab fa-linkedin-in"></i></a>
            </div>
          </div>

          <!-- Column 2 -->
          <div>
            <h4 class="text-white font-bold mb-6">Azienda</h4>
            <ul class="space-y-3 text-sm">
              <li><a href="#" class="hover:text-white transition-colors">Chi Siamo</a></li>
              <li><a href="#" class="hover:text-white transition-colors">Carriere</a></li>
              <li><a href="#" class="hover:text-white transition-colors">Blog</a></li>
              <li><a href="#" class="hover:text-white transition-colors">Press</a></li>
            </ul>
          </div>

          <!-- Column 3 -->
          <div>
            <h4 class="text-white font-bold mb-6">Risorse</h4>
            <ul class="space-y-3 text-sm">
              <li><a href="#" class="hover:text-white transition-colors">Supporto</a></li>
              <li><a href="#" class="hover:text-white transition-colors">Documentazione</a></li>
              <li><a href="#" class="hover:text-white transition-colors">Status</a></li>
              <li><a href="#" class="hover:text-white transition-colors">Privacy</a></li>
            </ul>
          </div>

          <!-- Column 4 -->
          <div>
            <h4 class="text-white font-bold mb-6">Newsletter</h4>
            <p class="text-sm mb-4">Iscriviti per ricevere le ultime novità.</p>
            <div class="flex flex-col gap-2">
              <input type="email" placeholder="La tua email" class="bg-gray-800 border border-gray-700 rounded px-4 py-2 text-white focus:outline-none focus:border-blue-500">
              <button class="bg-blue-600 text-white font-bold py-2 rounded hover:bg-blue-700 transition-colors">Iscriviti</button>
            </div>
          </div>

        </div>
        
        <div class="border-t border-gray-800 pt-8 text-center text-sm">
          &copy; 2024 Sarwisi. Tutti i diritti riservati.
        </div>
      </div>
    </footer>
  `
})
export class FooterComponent {}
