import { Component, input, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { TestimonialsData } from '../models/streamfield.model';
import { ScrollAnimationDirective } from '../directives/scroll-animation.directive';

@Component({
  selector: 'app-testimonials-block',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, NgOptimizedImage, ScrollAnimationDirective],
  template: `
    <section class="py-20 bg-blue-50 border-t border-blue-100">
      <div class="container mx-auto px-6">
        <h2 class="text-3xl font-bold text-center text-gray-800 mb-12" appScrollAnimation>{{ data().title }}</h2>
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
          @for (item of data().items; track $index) {
            <div class="bg-white p-8 rounded-2xl shadow-md relative mt-6 hover:shadow-lg transition-shadow duration-300"
                 appScrollAnimation
                 [style.transition-delay.ms]="$index * 200">
              
              <!-- Quote Icon -->
              <div class="absolute -top-4 left-8 w-8 h-8 bg-blue-500 flex items-center justify-center rounded-full text-white shadow-sm">
                <i class="fas fa-quote-left text-xs"></i>
              </div>
              
              <p class="text-gray-600 italic mb-6 pt-2">"{{ item.quote }}"</p>
              
              <div class="flex items-center">
                <div class="relative w-12 h-12 mr-4">
                  <img [ngSrc]="item.avatar" width="48" height="48" class="rounded-full object-cover border-2 border-white shadow-sm" alt="Author">
                </div>
                <div>
                  <h4 class="font-bold text-gray-900 text-sm">{{ item.author }}</h4>
                  <p class="text-blue-500 text-xs uppercase tracking-wide font-semibold">{{ item.role }}</p>
                </div>
              </div>
            </div>
          }
        </div>
      </div>
    </section>
  `
})
export class TestimonialsBlockComponent {
  data = input.required<TestimonialsData>();
}