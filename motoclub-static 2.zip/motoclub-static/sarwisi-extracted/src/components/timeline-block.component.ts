import { Component, input, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TimelineData } from '../models/streamfield.model';
import { ScrollAnimationDirective } from '../directives/scroll-animation.directive';

@Component({
  selector: 'app-timeline-block',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ScrollAnimationDirective],
  template: `
    <section class="py-24 bg-white overflow-hidden">
      <div class="container mx-auto px-6">
        
        <!-- Section Header -->
        <div class="text-center mb-20" appScrollAnimation>
          <span class="text-blue-600 font-semibold tracking-wider uppercase text-sm">Il Nostro Percorso</span>
          <h2 class="text-3xl md:text-4xl font-bold text-gray-900 mt-2">{{ data().title }}</h2>
          @if (data().description) {
            <p class="text-gray-500 mt-4 max-w-2xl mx-auto">{{ data().description }}</p>
          }
        </div>

        <!-- Timeline Container -->
        <div class="relative wrap overflow-hidden h-full">
          
          <!-- Vertical Center Line (Desktop) / Left Line (Mobile) -->
          <div class="absolute border-opacity-20 border-gray-300 h-full border-l-2 left-6 md:left-1/2 transform md:-translate-x-1/2" style="top: 0"></div>

          <!-- Timeline Items -->
           @for (item of data().items; track item.year) {
            <div class="mb-12 flex justify-between items-center w-full" 
                 [class.flex-row-reverse]="isEven($index)"
                 [class.md:flex-row-reverse]="isEven($index)"
                 [class.flex-row]="!isEven($index)"
                 appScrollAnimation
                 [style.transition-delay.ms]="$index * 100">
              
              <!-- Empty spacer for desktop layout (pushes content to one side) -->
              <div class="hidden md:block w-5/12"></div>

              <!-- Center Dot -->
              <div class="z-20 flex items-center order-1 bg-blue-600 shadow-xl w-8 h-8 rounded-full border-4 border-white absolute left-6 md:relative md:left-auto md:order-1">
                <div class="mx-auto w-2 h-2 bg-white rounded-full animate-pulse"></div>
              </div>
              
              <!-- Content Card -->
              <div class="order-1 bg-white rounded-lg shadow-lg border border-gray-100 w-full ml-16 md:ml-0 md:w-5/12 px-8 py-6 transform transition-transform duration-300 hover:-translate-y-1 hover:shadow-xl group">
                <span class="inline-block px-3 py-1 mb-3 text-xs font-semibold tracking-wider text-blue-600 uppercase bg-blue-50 rounded-full">
                  {{ item.year }}
                </span>
                <h3 class="mb-2 text-xl font-bold text-gray-800 group-hover:text-blue-600 transition-colors">{{ item.title }}</h3>
                <p class="text-sm leading-snug tracking-wide text-gray-600 text-opacity-100">
                  {{ item.description }}
                </p>
              </div>
            </div>
          }

        </div>
      </div>
    </section>
  `
})
export class TimelineBlockComponent {
  data = input.required<TimelineData>();

  isEven(index: number): boolean {
    return index % 2 !== 0;
  }
}
