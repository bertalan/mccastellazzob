import { Component } from '@angular/core';

@Component({
  selector: 'app-header',
  standalone: true,
  template: `
    <header class="bg-white shadow-sm sticky top-0 z-50">
      <nav class="container mx-auto px-6 h-20 flex items-center justify-between">
        <!-- Logo -->
        <a href="#" class="flex items-center gap-2">
          <div class="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold text-xl">
            S
          </div>
          <span class="text-2xl font-bold text-gray-800 tracking-tight">Sarwisi</span>
        </a>

        <!-- Desktop Menu -->
        <div class="hidden md:flex items-center space-x-8">
          <a href="#" class="text-gray-600 hover:text-blue-600 font-medium transition-colors">Home</a>
          <a href="#" class="text-gray-600 hover:text-blue-600 font-medium transition-colors">Servizi</a>
          <a href="#" class="text-gray-600 hover:text-blue-600 font-medium transition-colors">Chi Siamo</a>
          <a href="#" class="text-gray-600 hover:text-blue-600 font-medium transition-colors">Contatti</a>
        </div>

        <!-- CTA -->
        <div class="hidden md:block">
          <a href="#" class="px-5 py-2.5 rounded-lg border-2 border-blue-600 text-blue-600 font-bold hover:bg-blue-600 hover:text-white transition-all">
            Login
          </a>
        </div>

        <!-- Mobile Menu Button (Mock) -->
        <button class="md:hidden text-gray-600 focus:outline-none">
          <i class="fas fa-bars text-2xl"></i>
        </button>
      </nav>
    </header>
  `
})
export class HeaderComponent {}
