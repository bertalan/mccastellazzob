# Sistema Soci

## User Model Extension

```python
from django.contrib.auth.models import AbstractUser

class User(AbstractUser):
    phone = models.CharField(max_length=20, blank=True)
    fiscal_code = models.CharField(max_length=16, blank=True)
    birth_date = models.DateField(null=True, blank=True)
    photo = models.ForeignKey("wagtailimages.Image", null=True, blank=True, on_delete=models.SET_NULL)
    membership_type = models.ForeignKey("MembershipType", null=True, on_delete=models.SET_NULL)
    membership_date = models.DateField(null=True, blank=True)
    membership_expiry = models.DateField(null=True, blank=True)
    can_upload = models.BooleanField(default=False)
    
    @property
    def is_active_member(self):
        from django.utils import timezone
        return self.membership_expiry and self.membership_expiry >= timezone.now().date()
```

## MembershipType (Snippet)

```python
@register_snippet
class MembershipType(models.Model):
    name = models.CharField(max_length=50)
    annual_fee = models.DecimalField(max_digits=6, decimal_places=2)
    can_vote = models.BooleanBlock(default=True)
    can_upload_photos = models.BooleanField(default=False)
    class Meta:
        ordering = ["annual_fee"]
```

## Admin (ModelViewSet)

```python
from wagtail.admin.viewsets.model import ModelViewSet

class MemberViewSet(ModelViewSet):
    model = User
    icon = "user"
    menu_label = "Soci"
    list_display = ["username", "first_name", "last_name", "membership_type"]
    list_filter = ["membership_type"]
    search_fields = ["username", "first_name", "last_name"]

@hooks.register("register_admin_viewset")
def register_member_viewset():
    return MemberViewSet("members")
```

## Settings

```python
AUTH_USER_MODEL = "custom_user.User"
```

## Template

```html
{% if user.is_authenticated and user.is_active_member %}
<div class="member-badge">Socio fino al {{ user.membership_expiry }}</div>
{% endif %}
```

## Permessi

```python
def can_upload(user):
    return user.is_authenticated and user.is_active_member and user.can_upload
```
