# Velocity Theme - Components

## Navbar

```html
<!-- templates/themes/velocity/includes/navbar.html -->
<header id="navbar" class="fixed top-0 left-0 right-0 z-50">
    <nav class="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <a href="/" class="flex items-center gap-3">
            {% if settings.website.SiteSettings.logo %}
                {% image settings.website.SiteSettings.logo max-200x60 as logo %}
                <img src="{{ logo.url }}" alt="" class="h-10">
            {% else %}
                <span class="text-2xl font-bold text-white">{{ settings.website.SiteSettings.site_name }}</span>
            {% endif %}
        </a>
        
        <div class="hidden lg:flex items-center gap-8">
            {% for item in settings.website.SiteSettings.navbar.items.all %}
                <a href="{{ item.url }}" class="text-white/90 hover:text-white">{{ item.title }}</a>
            {% endfor %}
        </div>
        
        <a href="/contatti/" class="hidden lg:inline-flex bg-secondary text-primary px-5 py-2.5 rounded-full font-bold">
            Contattaci
        </a>
    </nav>
</header>
```

## Footer

```html
<!-- templates/themes/velocity/includes/footer.html -->
<footer class="bg-primary text-white pt-16 pb-8">
    <div class="max-w-7xl mx-auto px-6">
        <div class="grid md:grid-cols-4 gap-12 mb-12">
            <div class="md:col-span-2">
                <h3 class="text-2xl font-bold mb-4">{{ settings.website.SiteSettings.site_name }}</h3>
                <p class="text-white/70">{{ settings.website.SiteSettings.footer.description }}</p>
            </div>
            <div>
                <h4 class="font-bold mb-4">Menu</h4>
                <ul class="space-y-2 text-white/70">
                    {% for item in settings.website.SiteSettings.navbar.items.all %}
                    <li><a href="{{ item.url }}">{{ item.title }}</a></li>
                    {% endfor %}
                </ul>
            </div>
            <div>
                <h4 class="font-bold mb-4">Contatti</h4>
                {% with f=settings.website.SiteSettings.footer %}
                <ul class="space-y-2 text-white/70">
                    {% if f.email %}<li><i class="fas fa-envelope mr-2"></i>{{ f.email }}</li>{% endif %}
                    {% if f.phone %}<li><i class="fas fa-phone mr-2"></i>{{ f.phone }}</li>{% endif %}
                </ul>
                <div class="flex gap-4 mt-6">
                    {% if f.facebook %}<a href="{{ f.facebook }}" class="text-xl"><i class="fab fa-facebook"></i></a>{% endif %}
                    {% if f.instagram %}<a href="{{ f.instagram }}" class="text-xl"><i class="fab fa-instagram"></i></a>{% endif %}
                </div>
                {% endwith %}
            </div>
        </div>
        <div class="border-t border-white/10 pt-8 text-sm text-white/50">
            <p>© {% now "Y" %} {{ settings.website.SiteSettings.site_name }}</p>
        </div>
    </div>
</footer>
```

## Hero

```html
<section class="relative h-screen flex items-center justify-center">
    {% if hero_image %}{% image hero_image fill-1920x1080 as bg %}
    <div class="absolute inset-0">
        <img src="{{ bg.url }}" class="w-full h-full object-cover">
        <div class="absolute inset-0 bg-primary/80"></div>
    </div>
    {% endif %}
    <div class="relative z-10 text-center text-white px-6">
        <h1 class="text-5xl md:text-7xl font-black mb-6" data-aos="fade-up">{{ title }}</h1>
        {% if subtitle %}<p class="text-xl text-white/80 mb-10" data-aos="fade-up">{{ subtitle }}</p>{% endif %}
        {% if cta_link %}<a href="{{ cta_link }}" class="bg-secondary text-primary px-8 py-4 rounded-full font-bold">{{ cta_text }}</a>{% endif %}
    </div>
</section>
```
