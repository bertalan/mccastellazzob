# Theme: Terra (Eco-Friendly)

## Profile
| Aspect | Value |
|--------|-------|
| Framework | Pure CSS (no framework) |
| Fonts | System stack only (zero downloads) |
| Feel | Earth-conscious, sustainable, minimal |
| Bundle target | <15KB CSS total |

## Palette (CSS Variables)
```
--earth: #2D3B2D   --leaf: #4A7C59   --sand: #E8DFD0   --bark: #6B4423   --sun: #F2C94C
```

## Sustainability Principles

| Practice | Implementation |
|----------|----------------|
| System fonts | `font-family: system-ui, sans-serif` |
| No shadows | Borders only (GPU-friendly) |
| Dark mode default | OLED energy savings |
| Lazy everything | `loading="lazy"` on all media |
| Image budget | Max 100KB per image, WebP preferred |
| Single CSS file | Fewer HTTP requests |

## Component Guidelines

| Component | Style Notes |
|-----------|-------------|
| Hero | Text-only by default, no background image |
| Cards | 2px border, no shadow, minimal padding |
| Buttons | Solid color, high contrast |
| Grid | CSS Grid, `auto-fit` columns |

## Dark Mode (Default)
```css
@media (prefers-color-scheme: dark) {
  :root { --sand: #1A2E1A; --earth: #E8DFD0; }
}
```

## Files
```
templates/themes/terra/{base,includes/{navbar,footer}}.html
static/css/themes/terra/main.css  /* single file */
```

## Carbon Target
- <0.5g CO₂ per page view
- Validate: websitecarbon.com

## ⚠️ Wagtail Consideration
For eco sites, consider `wagtail-cache` or static site generation to reduce server processing.
