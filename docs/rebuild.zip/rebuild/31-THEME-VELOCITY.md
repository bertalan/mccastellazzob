# Theme: Velocity (Modern)

## Profile
| Aspect | Value |
|--------|-------|
| Framework | Tailwind CSS |
| Fonts | Inter (heading), Open Sans (body) |
| Feel | Dynamic, tech-forward, startup |
| Bundle target | <50KB CSS |

## Palette (CSS Variables)
```
--primary: #0F172A   --secondary: #F59E0B   --accent: #8B5CF6   --surface: #F8FAFC
```

## Component Guidelines

| Component | Style Notes |
|-----------|-------------|
| Hero | Fullscreen, background image, gradient overlay, massive heading |
| Cards | `rounded-2xl`, shadow-md → shadow-xl on hover |
| Buttons | Pill shape (`rounded-full`), icon + text, scale on hover |
| Grid | `grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8` |
| Navbar | Fixed, backdrop-blur, logo left, CTA right |

## Tailwind Specifics
- Use `@apply` in component CSS, not inline utility soup
- Dark mode: `dark:` prefix, toggle via JS `class="dark"` on `<html>`
- Purge unused classes in production

## Files
```
templates/themes/velocity/{base,includes/{navbar,footer,hero}}.html
static/css/themes/velocity/{base,components}.css
```

## Wagtail Integration
- Theme selected via `SiteSettings.theme`
- Blocks use `get_template()` for theme-aware rendering (see 35-THEMES-PROPOSAL)

## Performance Checklist
- [ ] `loading="lazy"` on images below fold
- [ ] Subset fonts (latin only)
- [ ] Tailwind purge enabled
- [ ] No unused JS
