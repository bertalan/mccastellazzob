# Multi-lingua

## Setup

```python
INSTALLED_APPS = [..., "wagtail_localize", "wagtail_localize.locales"]
WAGTAIL_I18N_ENABLED = True
WAGTAIL_CONTENT_LANGUAGES = LANGUAGES = [
    ("it", "Italiano"), ("en", "English"), ("de", "Deutsch"), ("fr", "Français"), ("es", "Español")
]
LANGUAGE_CODE = "it"
```

## URLs

```python
from django.conf.urls.i18n import i18n_patterns
urlpatterns = [path("admin/", include(wagtailadmin_urls))]
urlpatterns += i18n_patterns(path("", include(wagtail_urls)), prefix_default_language=True)
```

## TranslatableMixin

```python
from wagtail_localize.fields import TranslatableMixin

@register_snippet
class Navbar(TranslatableMixin, models.Model):
    name = models.CharField(max_length=50)
    class Meta:
        unique_together = [("translation_key", "locale")]
```

## Hreflang

```html
{% for t in page.get_translations %}
<link rel="alternate" hreflang="{{ t.locale.language_code }}" href="{{ t.full_url }}">
{% endfor %}
```

## Language Switcher

```html
{% get_current_language as lang %}
{% for t in page.get_translations %}
  {% if t.locale.language_code != lang %}
    <a href="{{ t.url }}">{{ t.locale.language_code|upper }}</a>
  {% endif %}
{% endfor %}
```

## Stringhe Template

```python
from django.utils.translation import gettext_lazy as _
hero_title = models.CharField(_("Titolo hero"), max_length=255)
```

```html
{% load i18n %}
<h1>{% trans "Benvenuto" %}</h1>
```

## Compilazione

```bash
python manage.py makemessages -l en -l de -l fr -l es
python manage.py compilemessages
```

## Fallback

```python
WAGTAILLOCALIZE_FALLBACK_TO_DEFAULT_LOCALE = True
```
