# Dynamic Color System

## ColorScheme Snippet

Editor-managed color schemes, switchable via SiteSettings or per-page.

```python
@register_snippet
class ColorScheme(TranslatableMixin, models.Model):
    name = models.CharField(max_length=50)  # "Velocity Dark", "Heritage Gold"
    
    # Core colors (required)
    primary = ColorField(default="#0F172A")
    secondary = ColorField(default="#F59E0B")
    accent = ColorField(default="#8B5CF6")
    
    # Surfaces
    surface = ColorField(default="#FFFFFF")
    surface_alt = ColorField(default="#F5F5F5")
    
    # Text
    text_primary = ColorField(default="#111111")
    text_muted = ColorField(default="#666666")
    
    panels = [
        FieldPanel("name"),
        MultiFieldPanel([
            FieldPanel("primary"), FieldPanel("secondary"), FieldPanel("accent"),
        ], heading="Brand Colors"),
        MultiFieldPanel([
            FieldPanel("surface"), FieldPanel("surface_alt"),
            FieldPanel("text_primary"), FieldPanel("text_muted"),
        ], heading="UI Colors"),
    ]
    
    def __str__(self):
        return self.name
```

## CSS Variables Output

Template tag to inject scheme as CSS variables:

```python
# apps/website/templatetags/color_tags.py
@register.simple_tag(takes_context=True)
def color_scheme_css(context):
    scheme = SiteSettings.for_request(context["request"]).color_scheme
    if not scheme:
        return ""
    return format_html(
        '<style>:root{{--primary:{};--secondary:{};--accent:{};'
        '--surface:{};--surface-alt:{};--text:{};--text-muted:{};}}</style>',
        scheme.primary, scheme.secondary, scheme.accent,
        scheme.surface, scheme.surface_alt, scheme.text_primary, scheme.text_muted
    )
```

## Base Template Integration

```html
<head>
  {% color_scheme_css %}
  <link rel="stylesheet" href="{% static 'css/themes/'|add:theme|add:'/main.css' %}">
</head>
```

## Usage in CSS

All themes use CSS variables, colors come from snippet:

```css
.btn-primary { background: var(--primary); color: var(--surface); }
.card { background: var(--surface); border-color: var(--secondary); }
h1, h2 { color: var(--text); }
p { color: var(--text-muted); }
```

## Theme + ColorScheme Relationship

| Theme | Provides | ColorScheme Provides |
|-------|----------|---------------------|
| All themes | Layout, components, fonts | Colors only |

## Predefined Schemes (Fixtures)

Create via `manage.py loaddata`:
```json
[{"name": "Velocity", "primary": "#0F172A", "secondary": "#F59E0B"},
 {"name": "Heritage", "primary": "#1E3A5F", "secondary": "#D4AF37"},
 {"name": "Terra", "primary": "#2D3B2D", "secondary": "#4A7C59"},
 {"name": "Zen", "primary": "#111111", "secondary": "#0066FF"}]
```

## Dependency

Requires `django-colorfield` or use `CharField` with HTML5 color input.
