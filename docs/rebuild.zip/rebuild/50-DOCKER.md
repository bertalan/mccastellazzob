# Docker Setup

## Dockerfile

```dockerfile
FROM python:3.11-slim
ENV PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
WORKDIR /app

RUN apt-get update && apt-get install -y \
    libpq-dev gcc libjpeg-dev zlib1g-dev && rm -rf /var/lib/apt/lists/*

COPY pyproject.toml .
RUN pip install --no-cache-dir -e .
COPY . .
RUN python manage.py collectstatic --noinput

COPY docker/entrypoint.sh /entrypoint.sh
RUN chmod +x /entrypoint.sh
EXPOSE 8000
ENTRYPOINT ["/entrypoint.sh"]
CMD ["gunicorn", "clubcms.wsgi:application", "--bind", "0.0.0.0:8000"]
```

## docker-compose.yml (Development)

```yaml
version: "3.9"
services:
  web:
    build: .
    ports: ["8000:8000"]
    volumes: [".:/app", "static:/app/staticfiles", "media:/app/media"]
    environment:
      - DEBUG=True
      - DATABASE_URL=postgres://postgres:postgres@db:5432/clubcms
      - SECRET_KEY=dev-secret-key
    depends_on: [db]
    command: python manage.py runserver 0.0.0.0:8000

  db:
    image: postgres:15-alpine
    volumes: [postgres_data:/var/lib/postgresql/data]
    environment: [POSTGRES_DB=clubcms, POSTGRES_USER=postgres, POSTGRES_PASSWORD=postgres]

volumes: {postgres_data:, static:, media:}
```

## entrypoint.sh

```bash
#!/bin/bash
set -e
echo "Waiting for database..."
while ! nc -z db 5432; do sleep 1; done
python manage.py migrate --noinput
python manage.py createcachetable --noinput || true
exec "$@"
```

## Makefile

```makefile
build: docker compose build
up: docker compose up -d
down: docker compose down
logs: docker compose logs -f web
shell: docker compose exec web python manage.py shell
migrate: docker compose exec web python manage.py migrate
```

## Comandi Utili

```bash
docker compose up --build -d          # Build e avvia
docker compose logs -f web            # Logs
docker compose exec web python manage.py shell  # Django shell
docker compose exec db pg_dump -U postgres clubcms > backup.sql  # Backup
```

## .env.example

```env
DEBUG=False
SECRET_KEY=your-secret-key
DATABASE_URL=postgres://user:pass@db:5432/clubcms
POSTGRES_DB=clubcms
POSTGRES_USER=clubcms
POSTGRES_PASSWORD=secure-password
```
