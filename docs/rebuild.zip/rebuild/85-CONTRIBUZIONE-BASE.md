# Contribuzione Soci - Base

## Tipi Contributo

| Tipo | Approvazione |
|------|--------------|
| Foto evento | Auto/moderata |
| Racconto gita | Moderata |
| Proposta evento | Moderata |
| Annuncio | Moderata |

## Form Racconto Gita

```python
# apps/website/forms.py
class StoryForm(forms.Form):
    title = forms.CharField(max_length=200)
    date = forms.DateField()
    intro = forms.CharField(max_length=200, widget=forms.Textarea)
    content = forms.CharField(widget=forms.Textarea)
    cover = forms.ImageField()
    gallery = forms.ImageField(required=False, widget=forms.ClearableFileInput(attrs={'multiple': True}))
```

## View Creazione

```python
@login_required
def submit_story(request):
    if request.method == 'POST':
        form = StoryForm(request.POST, request.FILES)
        if form.is_valid():
            news_index = NewsIndexPage.objects.first()
            
            # Upload cover
            cover = Image.objects.create(
                file=form.cleaned_data['cover'],
                title=form.cleaned_data['title'],
            )
            
            # Create draft page
            page = NewsPage(
                title=form.cleaned_data['title'],
                intro=form.cleaned_data['intro'],
                date_display=form.cleaned_data['date'],
                cover_image=cover,
                author=request.user,
                live=False,  # Bozza per moderazione
            )
            news_index.add_child(instance=page)
            
            messages.success(request, "Articolo inviato per approvazione!")
            return redirect('my_contributions')
    else:
        form = StoryForm()
    return render(request, 'website/submit_story.html', {'form': form})
```

## NewsPage Extension

```python
class NewsPage(JsonLdMixin, Page):
    # ... campi esistenti ...
    author = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL)
    is_user_contributed = models.BooleanField(default=False)
```

## Moderazione

Vedi [85-MODERAZIONE.md](85-MODERAZIONE.md).
