# Velocity Theme - Base Template

```html
<!-- templates/themes/velocity/base.html -->
<!DOCTYPE html>
<html lang="{{ LANGUAGE_CODE }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{% block title %}{{ page.title }}{% endblock %} | {{ settings.website.SiteSettings.site_name }}</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="{% static 'css/themes/velocity/base.css' %}" rel="stylesheet">
    
    <style>
    :root {
        --color-primary: {{ colors.primary|default:'#0F172A' }};
        --color-secondary: {{ colors.secondary|default:'#F59E0B' }};
        --color-accent: {{ colors.accent|default:'#8B5CF6' }};
    }
    </style>
</head>
<body class="bg-white text-gray-900">
    {% include "themes/velocity/includes/navbar.html" %}
    <main>{% block content %}{% endblock %}</main>
    {% include "themes/velocity/includes/footer.html" %}
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>AOS.init({ duration: 600, once: true });</script>
</body>
</html>
```

Navbar/Footer: vedi [EXAMPLE-VELOCITY-PARTS.md](EXAMPLE-VELOCITY-PARTS.md)
