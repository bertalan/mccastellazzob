# Project Structure

## Directory Layout

```
clubcms/
├── clubcms/                 # Django project config
│   ├── __init__.py
│   ├── settings/
│   │   ├── __init__.py
│   │   ├── base.py          # Settings comuni
│   │   ├── dev.py           # Development
│   │   └── prod.py          # Production
│   ├── urls.py
│   └── wsgi.py
│
├── apps/
│   ├── core/                # Utilities condivise
│   │   ├── seo.py           # JSON-LD mixin
│   │   ├── context_processors.py
│   │   └── wagtail_hooks.py
│   │
│   └── website/             # App principale
│       ├── models/
│       │   ├── __init__.py
│       │   ├── pages.py     # Tutti i Page models
│       │   ├── snippets.py  # Navbar, Footer, ColorScheme
│       │   └── settings.py  # SiteSettings
│       ├── blocks/
│       │   ├── __init__.py
│       │   ├── hero.py      # Hero blocks
│       │   ├── content.py   # Cards, CTA, Stats
│       │   └── media.py     # Gallery, Video
│       └── templatetags/
│           └── website_tags.py
│
├── templates/
│   ├── base.html            # Template base
│   ├── website/
│   │   ├── pages/           # Template pagine
│   │   └── blocks/          # Template blocchi
│   └── includes/
│       ├── navbar.html
│       ├── footer.html
│       └── lightbox.html
│
├── static/
│   ├── css/
│   │   ├── themes/
│   │   │   ├── modern.css
│   │   │   └── classic.css
│   │   └── components/
│   └── js/
│
└── locale/                  # Traduzioni
```

## Principi Organizzativi

### Models in Moduli Separati
- `pages.py`: HomePage, AboutPage, NewsPage, etc.
- `snippets.py`: elementi riutilizzabili
- `settings.py`: SiteSettings wagtail

### Blocks in Moduli Tematici
- `hero.py`: HeroSliderBlock, HeroCountdownBlock
- `content.py`: CardBlock, CTABlock, StatsBlock
- `media.py`: GalleryBlock, VideoBlock

### Templates Mirror Structure
- Template pagina: `templates/website/pages/{model_name}.html`
- Template blocco: `templates/website/blocks/{block_name}.html`

## File Chiave

| File | Scopo |
|------|-------|
| `apps/website/models/pages.py` | Tutti i modelli pagina |
| `apps/website/blocks/__init__.py` | Export blocchi |
| `apps/core/seo.py` | JsonLdMixin per schema.org |
| `templates/base.html` | Template master |

## Convenzioni Naming

- **Page models**: `{Name}Page` (es. `HomePage`, `NewsIndexPage`)
- **Blocks**: `{Name}Block` (es. `HeroSliderBlock`)
- **Templates**: snake_case (es. `home_page.html`)
- **CSS classes**: kebab-case (es. `hero-slider`)
