# Wagtail Admin Customization

## Branding CSS

```python
@hooks.register("insert_global_admin_css")
def global_admin_css():
    return format_html('<link rel="stylesheet" href="{}">', static("css/admin/custom.css"))
```

```css
:root { --w-color-primary: #1E3A5F; --w-color-secondary: #D4AF37; }
.button-primary { background-color: var(--w-color-secondary); }
```

## Dashboard Panel

```python
class WelcomePanel:
    order = 50
    def render(self):
        return render_to_string("admin/welcome_panel.html")

@hooks.register("construct_homepage_panels")
def add_welcome_panel(request, panels):
    panels.append(WelcomePanel())
```

## Menu Custom

```python
@hooks.register("construct_main_menu")
def hide_reports_menu(request, menu_items):
    if not request.user.is_superuser:
        menu_items[:] = [i for i in menu_items if i.name != "reports"]

@hooks.register("register_admin_menu_item")
def register_help_menu():
    return MenuItem("Guida", "/admin/help/", icon_name="help", order=10000)
```

## RichText Features

```python
WAGTAILADMIN_RICH_TEXT_EDITORS = {
    "default": {"WIDGET": "wagtail.admin.rich_text.DraftailRichTextArea",
        "OPTIONS": {"features": ["h2", "h3", "bold", "italic", "link", "ol", "ul"]}},
    "minimal": {"WIDGET": "wagtail.admin.rich_text.DraftailRichTextArea",
        "OPTIONS": {"features": ["bold", "italic", "link"]}}
}
```

## Action Menu

```python
class PreviewMenuItem(ActionMenuItem):
    label = "Anteprima Live"
    def get_url(self, context): return context["page"].url

@hooks.register("register_page_action_menu_item")
def register_preview(): return PreviewMenuItem(order=100)
```

## Settings

```python
WAGTAIL_SITE_NAME = "Club CMS"
WAGTAILADMIN_BASE_URL = "https://example.com"
```
