# Gallery System

## Architettura

Usa **Wagtail Collections** native per organizzare immagini.

## GalleryPage

```python
class GalleryPage(JsonLdMixin, Page):
    """Lista album usando Collections."""
    template = "website/pages/gallery_page.html"
    max_count = 1
    intro = models.CharField(max_length=255, blank=True)
    
    def get_context(self, request):
        context = super().get_context(request)
        from wagtail.models import Collection
        from wagtail.images.models import Image
        
        collections = []
        for coll in Collection.objects.exclude(name="Root"):
            images = Image.objects.filter(collection=coll)
            if images.exists():
                collections.append({
                    "collection": coll,
                    "cover": images.first(),
                    "count": images.count(),
                })
        context["collections"] = collections
        return context
```

## GalleryBlock (StreamField)

```python
class GalleryBlock(blocks.StructBlock):
    collection = CollectionChooserBlock()
    columns = blocks.ChoiceBlock(choices=[
        ("2", "2"), ("3", "3"), ("4", "4")
    ], default="4")
    max_images = blocks.IntegerBlock(default=12)
    
    class Meta:
        icon = "image"
        template = "website/blocks/gallery_block.html"
    
    def get_context(self, value, parent_context=None):
        context = super().get_context(value, parent_context)
        from wagtail.images.models import Image
        context["images"] = Image.objects.filter(
            collection=value["collection"]
        )[:value["max_images"]]
        return context
```

## Template

```django
{# templates/website/blocks/gallery_block.html #}
{% load wagtailimages_tags %}
<div class="gallery grid grid-cols-{{ self.columns }} gap-4">
    {% for image in images %}
        {% image image fill-400x300 as thumb %}
        {% image image max-1920x1080 as full %}
        <div class="gallery-item cursor-pointer" 
             onclick="openLightbox('{{ full.url }}', '{{ image.title }}')">
            <img src="{{ thumb.url }}" alt="{{ image.title }}" loading="lazy">
        </div>
    {% endfor %}
</div>
```

## CollectionChooserBlock

```python
from wagtail.blocks import ChooserBlock

class CollectionChooserBlock(ChooserBlock):
    target_model = "wagtailcore.Collection"
    
    class Meta:
        icon = "folder-open-inverse"
```

## Vantaggi Collections

| Aspetto | Beneficio |
|---------|-----------|
| Integrato | Nessun modello custom |
| Admin | Gestione in Media Library |
| Permessi | ACL native |
| Riutilizzo | Stesse immagini ovunque |

## Upload Frontend (Soci)

Vedi [81-GALLERY-UPLOAD.md](81-GALLERY-UPLOAD.md) per upload da soci.
