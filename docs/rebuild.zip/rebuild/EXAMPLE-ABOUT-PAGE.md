# Esempio: AboutPage

## Model

```python
class AboutPage(JsonLdMixin, Page):
    schema_type = "Organization"
    template = "website/pages/about_page.html"
    
    intro = models.CharField(_("Sottotitolo"), max_length=255, blank=True)
    cover_image = models.ForeignKey(Image, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    body = StreamField(CONTENT_BLOCKS, blank=True, use_json_field=True)
    
    content_panels = Page.content_panels + [
        MultiFieldPanel([FieldPanel("intro"), FieldPanel("cover_image")], heading="Header"),
        FieldPanel("body"),
    ]
    
    def get_json_ld_data(self):
        return {"@type": "Organization", "name": self.title, "url": self.full_url, "description": self.intro}
```

## Template

```html
{% extends "base.html" %}
{% load wagtailcore_tags wagtailimages_tags %}

{% block content %}
<header class="hero-simple">
  {% if page.cover_image %}
    {% image page.cover_image fill-1920x600 as hero_img %}
    <div class="hero-bg" style="background-image:url('{{ hero_img.url }}')"></div>
  {% endif %}
  <h1>{{ page.title }}</h1>
  {% if page.intro %}<p class="lead">{{ page.intro }}</p>{% endif %}
</header>

<main class="container py-5">
  {% for block in page.body %}
    <section>{% include_block block %}</section>
  {% endfor %}
</main>
{% endblock %}
```

## Blocks Consigliati

```python
ABOUT_BLOCKS = [
    ("rich_text", blocks.RichTextBlock()),
    ("timeline", TimelineBlock()),   # Storia
    ("team", TeamBlock()),           # Direttivo
    ("stats", StatsBlock()),         # Numeri
    ("gallery", GalleryBlock()),     # Foto
    ("cta", CTABlock()),             # CTA
]
```

## Vantaggi

| Aspetto | Beneficio |
|---------|-----------|
| StreamField | Editor sceglie ordine blocchi |
| JSON-LD | SEO automatico |
| Multi-lingua | wagtail-localize ready |
