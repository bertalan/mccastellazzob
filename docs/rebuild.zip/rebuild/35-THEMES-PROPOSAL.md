# Theme System Architecture

## Four Themes

| Theme | Framework | Bundle | Use Case |
|-------|-----------|--------|----------|
| Velocity | Tailwind | <50KB | Tech, startup |
| Heritage | Bootstrap 5 | <80KB | Traditional, luxury |
| Terra | Pure CSS | <15KB | Eco-conscious |
| Zen | Pure CSS | <10KB | Content-first |

## Theme Selection: SiteSettings

```python
# apps/website/models/settings.py
from wagtail.contrib.settings.models import BaseSiteSetting, register_setting
from django.db import models

@register_setting
class SiteSettings(BaseSiteSetting):
    theme = models.CharField(max_length=20, choices=[
        ("velocity", "Velocity"), ("heritage", "Heritage"),
        ("terra", "Terra"), ("zen", "Zen")
    ], default="velocity")
    
    panels = [FieldPanel("theme")]
```

## Context Processor

```python
# apps/core/context_processors.py
def theme_context(request):
    from apps.website.models import SiteSettings
    settings = SiteSettings.for_request(request)
    return {"theme": settings.theme}
```

Register in `settings.py` → `TEMPLATES[0]['OPTIONS']['context_processors']`

## Template Strategy

```html
<!-- templates/base.html -->
{% extends "themes/"|add:theme|add:"/base.html" %}

<!-- In page templates -->
{% include "themes/"|add:theme|add:"/includes/hero.html" %}
```

## Block Theme-Awareness (Wagtail 7.x Native)

```python
# apps/website/blocks/base.py
class ThemedBlock(blocks.StructBlock):
    """Mixin for theme-aware blocks"""
    def get_template(self, context=None):
        theme = context.get("theme", "velocity") if context else "velocity"
        block_name = self.__class__.__name__.lower().replace("block", "")
        return f"themes/{theme}/blocks/{block_name}.html"

# Usage
class CardBlock(ThemedBlock):
    title = blocks.CharBlock()
    # ... template auto-resolved to themes/{theme}/blocks/card.html
```

## File Structure

```
templates/themes/{velocity,heritage,terra,zen}/
├── base.html
├── includes/{navbar,footer,hero}.html
└── blocks/{card,hero_slider,cta,...}.html

static/css/themes/{velocity,heritage}/  → multiple files
static/css/themes/{terra,zen}/main.css  → single file
```

## 💡 Advanced: Per-Page Theme Override

Add optional field to `BasePage` for page-level override:

```python
class BasePage(Page):
    theme_override = models.CharField(max_length=20, blank=True, choices=[...])
    
    def get_theme(self):
        return self.theme_override or SiteSettings.for_request(self.get_request()).theme
```

## Feature Matrix

| Feature | V | H | T | Z |
|---------|---|---|---|---|
| Dark mode | ✓ | – | ✓ | – |
| Animations | ✓ | ✓ | – | – |
| Multi-lang | ✓ | ✓ | ✓ | ✓ |
| JSON-LD | ✓ | ✓ | ✓ | ✓ |
| Images | Rich | Rich | Minimal | None |
