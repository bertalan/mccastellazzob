# PWA - Progressive Web App

## Manifest

```python
# apps/core/views.py
from django.http import JsonResponse
from wagtail.contrib.settings.models import BaseSiteSetting

def manifest_json(request):
    settings = SiteSettings.for_request(request)
    return JsonResponse({
        "name": settings.site_name,
        "short_name": settings.site_name[:12],
        "start_url": "/",
        "display": "standalone",
        "theme_color": settings.color_scheme.primary if settings.color_scheme else "#1E3A5F",
        "background_color": "#ffffff",
        "icons": [
            {"src": "/static/icons/192.png", "sizes": "192x192", "type": "image/png"},
            {"src": "/static/icons/512.png", "sizes": "512x512", "type": "image/png"},
        ]
    })
```

## Service Worker

```javascript
// static/js/sw.js
const CACHE = 'v1';
const OFFLINE_URL = '/offline/';

self.addEventListener('install', e => {
    e.waitUntil(
        caches.open(CACHE).then(cache => cache.addAll([
            '/', '/offline/', '/static/css/main.css', '/static/js/main.js'
        ]))
    );
});

self.addEventListener('fetch', e => {
    if (e.request.mode === 'navigate') {
        e.respondWith(
            fetch(e.request).catch(() => caches.match(OFFLINE_URL))
        );
    } else {
        e.respondWith(
            caches.match(e.request).then(r => r || fetch(e.request))
        );
    }
});
```

## Template Base

```django
<head>
    <link rel="manifest" href="/manifest.json">
    <meta name="theme-color" content="{{ colors.primary }}">
    <meta name="apple-mobile-web-app-capable" content="yes">
</head>
<body>
    ...
    <script>
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('/sw.js');
        }
    </script>
</body>
```

## Push Notifications

Vedi [84-PWA-PUSH.md](84-PWA-PUSH.md).

## Mobile Design

| Aspetto | Implementazione |
|---------|-----------------|
| Breakpoint | < 640px mobile, 640-1024 tablet |
| Touch | Min 44x44px bottoni |
| Images | Lazy load |
| CSS | Critical inline |
