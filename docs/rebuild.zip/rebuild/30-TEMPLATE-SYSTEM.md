# Template System

## Principi

- Django templates nativi, template inheritance, include per componenti

## Base Template

```html
<!-- templates/base.html -->
<!DOCTYPE html>
<html lang="{{ LANGUAGE_CODE }}">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{% block title %}{{ page.title }}{% endblock %}</title>
  {% block meta %}<meta name="description" content="{{ page.search_description }}">{% endblock %}
  <link href="{% static 'css/themes/'|add:theme|add:'.css' %}" rel="stylesheet">
  <style>:root{--color-primary:{{ colors.primary }};--color-secondary:{{ colors.secondary }};}</style>
</head>
<body class="theme-{{ theme }}">
  {% include "includes/navbar.html" %}
  <main>{% block content %}{% endblock %}</main>
  {% include "includes/footer.html" %}
  <script src="{% static 'js/main.js' %}"></script>
</body>
</html>
```

## Page Template

```html
<!-- templates/website/pages/home_page.html -->
{% extends "base.html" %}
{% load wagtailcore_tags wagtailimages_tags %}
{% block content %}
  {% for block in page.body %}{% include_block block %}{% endfor %}
{% endblock %}
```

## Block Template

```html
<!-- templates/website/blocks/hero_slider_block.html -->
{% load wagtailimages_tags %}
<section class="hero-slider">
  {% for slide in self.slides %}
    {% image slide.image fill-1920x1080 as img %}
    <div class="slide"><img src="{{ img.url }}" alt=""><h2>{{ slide.title }}</h2></div>
  {% endfor %}
</section>
```

## Template Tags

| Tag | Uso |
|-----|-----|
| `{% include_block block %}` | Renderizza StreamField block |
| `{% pageurl page %}` | URL pagina |
| `{% image img fill-800x600 %}` | Immagine processata |

## Gerarchia File

```
templates/
├── base.html
├── includes/{navbar,footer}.html
└── website/
    ├── pages/{home,about,news}_page.html
    └── blocks/{hero,cta,card}_block.html
```
