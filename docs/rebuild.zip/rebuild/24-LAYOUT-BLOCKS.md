# Layout Blocks

## GridBlock

```python
class GridItemBlock(blocks.StructBlock):
    image = ImageChooserBlock(required=False)
    title = blocks.CharBlock(required=False)
    content = blocks.RichTextBlock(required=False)
    column_span = blocks.ChoiceBlock(choices=[("1","1"),("2","2")], default="1")

class GridBlock(blocks.StructBlock):
    items = blocks.ListBlock(GridItemBlock())
    columns = blocks.ChoiceBlock(choices=[("2","2"),("3","3"),("4","4")], default="3")
    gap = blocks.ChoiceBlock(choices=[("sm","8px"),("md","16px"),("lg","24px")], default="md")
    class Meta:
        template = "website/blocks/grid_block.html"
        icon = "grip"
```

## TwoColumnBlock

```python
class TwoColumnBlock(blocks.StructBlock):
    left = blocks.StreamBlock([("text", blocks.RichTextBlock()), ("image", ImageChooserBlock())])
    right = blocks.StreamBlock([("text", blocks.RichTextBlock()), ("image", ImageChooserBlock())])
    ratio = blocks.ChoiceBlock(choices=[("50-50","50/50"),("60-40","60/40")], default="50-50")
    class Meta:
        template = "website/blocks/two_column_block.html"
        icon = "columns"
```

## AccordionBlock

```python
class AccordionItemBlock(blocks.StructBlock):
    title = blocks.CharBlock()
    content = blocks.RichTextBlock()

class AccordionBlock(blocks.StructBlock):
    items = blocks.ListBlock(AccordionItemBlock())
    allow_multiple = blocks.BooleanBlock(default=False, required=False)
    class Meta:
        template = "website/blocks/accordion_block.html"
        icon = "list-ul"
```

## TabsBlock

```python
class TabBlock(blocks.StructBlock):
    title = blocks.CharBlock()
    content = blocks.RichTextBlock()

class TabsBlock(blocks.StructBlock):
    tabs = blocks.ListBlock(TabBlock())
    class Meta:
        template = "website/blocks/tabs_block.html"
        icon = "folder"
```

## Template Grid

```html
<div class="grid grid-cols-{{ self.columns }} gap-{{ self.gap }}">
  {% for item in self.items %}
  <div class="{% if item.column_span == '2' %}col-span-2{% endif %}">
    {{ item.content }}
  </div>
  {% endfor %}
</div>
```

## Registrazione

```python
LAYOUT_BLOCKS = [("grid", GridBlock()), ("two_column", TwoColumnBlock()), ("accordion", AccordionBlock()), ("tabs", TabsBlock())]
```
