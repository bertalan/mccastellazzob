# Media Blocks

## GalleryBlock

```python
class GalleryBlock(blocks.StructBlock):
    collection = CollectionChooserBlock()
    columns = blocks.ChoiceBlock(choices=[("2","2"),("3","3"),("4","4")], default="4")
    max_images = blocks.IntegerBlock(default=12)
    class Meta:
        icon = "image"
        template = "website/blocks/gallery_block.html"
```

## VideoEmbedBlock

```python
class VideoEmbedBlock(blocks.StructBlock):
    video = EmbedBlock()
    caption = blocks.CharBlock(max_length=255, required=False)
    class Meta:
        icon = "media"
```

## DocumentBlock

```python
class DocumentBlock(blocks.StructBlock):
    document = DocumentChooserBlock()
    title = blocks.CharBlock(max_length=100, required=False)
    class Meta:
        icon = "doc-full"

class DocumentListBlock(blocks.StructBlock):
    title = blocks.CharBlock(max_length=100, required=False)
    documents = blocks.ListBlock(DocumentBlock())
```

## ImageBlock

```python
class ImageBlock(blocks.StructBlock):
    image = ImageChooserBlock()
    caption = blocks.CharBlock(max_length=255, required=False)
    alignment = blocks.ChoiceBlock(choices=[("left","Sx"),("center","C"),("right","Dx")], default="center")
    size = blocks.ChoiceBlock(choices=[("small","S"),("medium","M"),("large","L")], default="large")
    class Meta:
        icon = "image"
```

## MapBlock

```python
class MapBlock(blocks.StructBlock):
    embed_code = blocks.RawHTMLBlock(required=False)
    latitude = blocks.FloatBlock(required=False)
    longitude = blocks.FloatBlock(required=False)
    height = blocks.ChoiceBlock(choices=[("300","S"),("400","M"),("500","L")], default="400")
    class Meta:
        icon = "site"
```

## AudioBlock

```python
class AudioBlock(blocks.StructBlock):
    audio_file = DocumentChooserBlock()
    title = blocks.CharBlock(max_length=100, required=False)
    class Meta:
        icon = "media"
```

## Registrazione

```python
MEDIA_BLOCKS = [("gallery", GalleryBlock()), ("video", VideoEmbedBlock()), 
    ("documents", DocumentListBlock()), ("image", ImageBlock()), ("map", MapBlock())]
```
