# Eventi - Sistema Iscrizioni

## EventDetailPage (esteso)

```python
class EventDetailPage(JsonLdMixin, Page):
    # ... campi base da 13-NEWS-EVENTS.md ...
    registration_open = models.BooleanField(default=False)
    registration_deadline = models.DateField(null=True, blank=True)
    max_participants = models.PositiveIntegerField(default=0)
    allow_guests = models.BooleanField(default=False)
    participation_fee = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    meeting_point = models.CharField(max_length=255, blank=True)
    difficulty = models.CharField(max_length=20, choices=[
        ("easy","Facile"),("medium","Media"),("hard","Impegnativa")
    ], default="medium")
    
    @property
    def available_spots(self):
        if self.max_participants == 0: return None
        return self.max_participants - self.attendances.filter(status="confirmed").count()
```

## EventAttendance (Django Model)

```python
class EventAttendance(models.Model):
    """Iscrizione evento - Django Model, NON Snippet."""
    class Status(models.TextChoices):
        REGISTERED = "registered", "Iscritto"
        CONFIRMED = "confirmed", "Confermato"
        CANCELLED = "cancelled", "Annullato"
    
    event = models.ForeignKey(EventDetailPage, on_delete=models.CASCADE, related_name="attendances")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.REGISTERED)
    registered_at = models.DateTimeField(auto_now_add=True)
    guests = models.PositiveIntegerField(default=0)
    notes = models.TextField(blank=True)
    
    class Meta:
        unique_together = ["event", "user"]
```

## Admin (ModelViewSet)

```python
class AttendanceViewSet(ModelViewSet):
    model = EventAttendance
    icon = "group"
    menu_label = "Iscrizioni"
    list_display = ["event", "user", "status", "registered_at"]
    list_filter = ["status", "event"]

@hooks.register("register_admin_viewset")
def register_attendance_viewset(): return AttendanceViewSet("attendances")
```

## View Iscrizione

```python
@login_required
@require_POST
def register_for_event(request, event_id):
    event = get_object_or_404(EventDetailPage, id=event_id)
    if not event.registration_open or (event.available_spots and event.available_spots <= 0):
        return redirect(event.url)
    EventAttendance.objects.get_or_create(event=event, user=request.user)
    return redirect(event.url)
```

## Template

```django
{% if event.registration_open and user.is_authenticated and not user_registered %}
  <form method="post" action="{% url 'register_event' event.id %}">{% csrf_token %}<button>Partecipa</button></form>
{% endif %}
```
