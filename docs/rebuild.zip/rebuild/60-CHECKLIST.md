# Checklist Implementazione

## FASE 1: Setup (1-2 giorni)
- [ ] Python 3.12+ venv, wagtail, django
- [ ] Settings split (base, dev, prod)
- [ ] Apps: `core`, `website`, `custom_user`
- [ ] PostgreSQL + prima migration
- [ ] Docker + docker-compose

## FASE 2: Modelli Base (2-3 giorni)
- [ ] `BasePage` con SEO (og_image, search_description)
- [ ] `HomePage` con StreamField
- [ ] Snippets: `ColorScheme`, `Navbar`, `Footer`
- [ ] `SiteSettings` con `register_setting`

## FASE 3: StreamField Blocks (3-4 giorni)
- [ ] `BaseBlock` con alignment, css_class
- [ ] Hero: `HeroSliderBlock`, `HeroBannerBlock`
- [ ] Content: `CardBlock`, `CardGridBlock`, `CTABlock`, `StatsBlock`
- [ ] Media: `GalleryBlock`, `VideoEmbedBlock`, `MapBlock`
- [ ] Layout: `AccordionBlock`, `TabsBlock`, `TwoColumnBlock`

## FASE 4: Pagine (2-3 giorni)
- [ ] Statiche: `AboutPage`, `ContactPage`, `PrivacyPage`, `BoardPage`
- [ ] News: `NewsIndexPage`, `NewsPage` + tags
- [ ] Eventi: `EventsPage`, `EventDetailPage`
- [ ] Gallery: Collections + `GalleryIndexPage`

## FASE 5: Template System (3-4 giorni)
- [ ] base.html, navbar.html, footer.html
- [ ] Block templates
- [ ] Color System (CSS variables, context processor)
- [ ] Tailwind build + collectstatic

## FASE 6: Features (2-3 giorni)
- [ ] SEO: JSON-LD, sitemap.xml, robots.txt, Open Graph
- [ ] Multilingua: wagtail-localize, IT/EN/DE/FR/ES
- [ ] Admin: logo, dashboard, help panels

## FASE 7: Testing (2 giorni)
- [ ] Unit: modelli, blocks, context processors
- [ ] Integration: navigation, form, multilingua

## FASE 8: Deploy (1-2 giorni)
- [ ] Nginx + SSL (Let's Encrypt)
- [ ] Gunicorn + systemd
- [ ] Backup database + media
- [ ] Monitoring (Sentry, uptime)

## FASE 9: Migrazione (1-2 giorni)
- [ ] Export pagine/media/utenti esistenti
- [ ] Script importazione
- [ ] Redirect 301 se necessari

---

**Totale: 17-24 giorni**

| Priorità | Elementi |
|----------|----------|
| Alta (MVP) | Setup, HomePage, pagine statiche, 1 theme, deploy |
| Media | News/Eventi, Gallery, multilingua, SEO |
| Bassa | Secondo theme, E2E tests, dashboard avanzata |
