# PWA - Push Notifications

## Setup VAPID

```bash
pip install django-webpush
```

```python
# settings.py
WEBPUSH_SETTINGS = {
    "VAPID_PUBLIC_KEY": "...",
    "VAPID_PRIVATE_KEY": "...",
    "VAPID_ADMIN_EMAIL": "admin@example.com"
}
```

## Subscription Model

```python
# apps/website/models/push.py
class PushSubscription(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    endpoint = models.TextField()
    p256dh = models.CharField(max_length=100)
    auth = models.CharField(max_length=50)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ["user", "endpoint"]
```

## Subscribe View

```python
@login_required
def subscribe_push(request):
    if request.method == "POST":
        data = json.loads(request.body)
        PushSubscription.objects.update_or_create(
            user=request.user,
            endpoint=data["endpoint"],
            defaults={
                "p256dh": data["keys"]["p256dh"],
                "auth": data["keys"]["auth"],
            }
        )
        return JsonResponse({"ok": True})
```

## Send Notification

```python
from pywebpush import webpush

def send_push(user, title, body, url=None):
    for sub in PushSubscription.objects.filter(user=user, is_active=True):
        try:
            webpush(
                subscription_info={
                    "endpoint": sub.endpoint,
                    "keys": {"p256dh": sub.p256dh, "auth": sub.auth}
                },
                data=json.dumps({"title": title, "body": body, "url": url}),
                vapid_private_key=settings.WEBPUSH_SETTINGS["VAPID_PRIVATE_KEY"],
                vapid_claims={"sub": f"mailto:{settings.WEBPUSH_SETTINGS['VAPID_ADMIN_EMAIL']}"}
            )
        except Exception:
            sub.is_active = False
            sub.save()
```

## Tipi Notifiche

| Evento | Notifica |
|--------|----------|
| Nuovo evento | "Nuovo evento: {title}" |
| Reminder | "Domani: {event} ore {time}" |
| Quota scadenza | "Tessera scade tra 7 giorni" |
| Nuove foto | "{n} nuove foto da {event}" |

## Frontend Subscribe

```javascript
async function subscribePush() {
    const reg = await navigator.serviceWorker.ready;
    const sub = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: VAPID_PUBLIC_KEY
    });
    await fetch('/api/push/subscribe/', {
        method: 'POST',
        body: JSON.stringify(sub.toJSON()),
        headers: {'Content-Type': 'application/json', 'X-CSRFToken': csrfToken}
    });
}
```
