# Modelli Transazionali

## Regola

**Django Model** per dati ad alto volume (attività, reazioni, commenti).
**Snippet** solo per contenuti editoriali gestiti manualmente.

## Activity

```python
class Activity(models.Model):
    class ActionType(models.TextChoices):
        PHOTO = "photo", "Foto"
        EVENT = "event", "Evento"
        MEMBERSHIP = "membership", "Socio"
    
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    action_type = models.CharField(max_length=20, choices=ActionType.choices)
    verb = models.CharField(max_length=100)
    target_type = models.CharField(max_length=50)
    target_id = models.PositiveIntegerField()
    target_title = models.CharField(max_length=255)
    target_url = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ["-created_at"]
```

## Reaction

```python
class Reaction(models.Model):
    class ReactionType(models.TextChoices):
        LIKE = "like", "👍"
        LOVE = "love", "❤️"
    
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    content_type = models.CharField(max_length=50)
    object_id = models.PositiveIntegerField()
    reaction_type = models.CharField(max_length=10, choices=ReactionType.choices)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ["user", "content_type", "object_id"]
```

## Comment

```python
class Comment(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    content_type = models.CharField(max_length=50)
    object_id = models.PositiveIntegerField()
    text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    is_approved = models.BooleanField(default=True)
    parent = models.ForeignKey("self", null=True, blank=True, on_delete=models.CASCADE)
```

## Admin (ModelViewSet)

```python
class ActivityViewSet(ModelViewSet):
    model = Activity
    icon = "history"
    list_display = ["actor", "verb", "target_title", "created_at"]

class CommentViewSet(ModelViewSet):
    model = Comment
    icon = "comment"
    list_display = ["user", "text", "is_approved"]
    list_filter = ["is_approved"]
```

## Signal

```python
@receiver(post_save, sender=EventAttendance)
def log_event_registration(sender, instance, created, **kwargs):
    if created:
        Activity.objects.create(
            actor=instance.user, action_type=Activity.ActionType.EVENT,
            verb="iscritto a", target_type="EventDetailPage",
            target_id=instance.event.id, target_title=instance.event.title
        )
```
