# Content Pages

## Pattern Comune

Header (titolo + intro) + Body StreamField + JSON-LD automatico

## ContactPage

```python
class ContactPage(JsonLdMixin, Page):
    schema_type = "ContactPage"
    max_count = 1
    
    intro = models.CharField(max_length=255, blank=True)
    form_title = models.CharField(max_length=100, default="Contattaci")
    success_message = models.TextField(default="Grazie!")
    show_map = models.BooleanField(default=True)
    map_embed = models.TextField(blank=True)
    body = StreamField(CONTENT_BLOCKS, blank=True, use_json_field=True)
    
    content_panels = Page.content_panels + [
        FieldPanel("intro"), FieldPanel("form_title"),
        FieldPanel("show_map"), FieldPanel("map_embed"), FieldPanel("body")
    ]
```

## PrivacyPage

```python
class PrivacyPage(JsonLdMixin, Page):
    max_count = 1
    body = StreamField([("rich_text", blocks.RichTextBlock())], use_json_field=True)
    last_updated = models.DateField(auto_now=True)
```

## BoardPage (Direttivo)

```python
class BoardPage(JsonLdMixin, Page):
    parent_page_types = ["website.AboutPage"]
    intro = models.CharField(max_length=255, blank=True)
    body = StreamField([
        ("team_member", TeamMemberBlock()),
        ("rich_text", blocks.RichTextBlock()),
    ], use_json_field=True)

class TeamMemberBlock(blocks.StructBlock):
    name = blocks.CharBlock(max_length=100)
    role = blocks.CharBlock(max_length=100)
    photo = ImageChooserBlock(required=False)
    bio = blocks.TextBlock(required=False)
    class Meta:
        icon = "user"
        template = "website/blocks/team_member_block.html"
```

## TransparencyPage

```python
class TransparencyPage(JsonLdMixin, Page):
    intro = models.CharField(max_length=255, blank=True)
    body = StreamField([
        ("document_group", DocumentGroupBlock()),
        ("rich_text", blocks.RichTextBlock()),
    ], use_json_field=True)

class DocumentGroupBlock(blocks.StructBlock):
    title = blocks.CharBlock(max_length=100)
    documents = blocks.ListBlock(blocks.StructBlock([
        ("title", blocks.CharBlock()),
        ("document", DocumentChooserBlock()),
        ("year", blocks.IntegerBlock(required=False)),
    ]))
    class Meta:
        icon = "doc-full"
```

## Riepilogo

| Page | Uso | max_count |
|------|-----|-----------|
| ContactPage | Contatti + form | 1 |
| PrivacyPage | Privacy policy | 1 |
| BoardPage | Direttivo club | - |
| TransparencyPage | Documenti legali | - |
