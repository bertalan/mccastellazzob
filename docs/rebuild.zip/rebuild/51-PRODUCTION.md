# Production Deployment

## Checklist Pre-Deploy

- [ ] `DEBUG=False`, `SECRET_KEY` sicuro, `ALLOWED_HOSTS` configurato
- [ ] PostgreSQL, static files, HTTPS, backup automatici

## Settings Production

```python
# clubcms/settings/prod.py
from .base import *
import os

DEBUG = False
SECRET_KEY = os.environ["SECRET_KEY"]
ALLOWED_HOSTS = os.environ.get("ALLOWED_HOSTS", "").split(",")

DATABASES = {"default": {
    "ENGINE": "django.db.backends.postgresql",
    "NAME": os.environ["DB_NAME"], "USER": os.environ["DB_USER"],
    "PASSWORD": os.environ["DB_PASSWORD"],
    "HOST": os.environ.get("DB_HOST", "localhost"),
}}

# Security
SECURE_SSL_REDIRECT = SESSION_COOKIE_SECURE = CSRF_COOKIE_SECURE = True
X_FRAME_OPTIONS = "DENY"

# Static
STATIC_ROOT = BASE_DIR / "staticfiles"
STATICFILES_STORAGE = "whitenoise.storage.CompressedManifestStaticFilesStorage"
```

## docker-compose.prod.yml

```yaml
version: "3.9"
services:
  web:
    build: .
    environment: [DEBUG=False, DATABASE_URL=${DATABASE_URL}, SECRET_KEY=${SECRET_KEY}]
    restart: unless-stopped
  db:
    image: postgres:15-alpine
    volumes: [postgres_data:/var/lib/postgresql/data]
    restart: unless-stopped
  nginx:
    image: nginx:alpine
    ports: ["80:80", "443:443"]
    volumes: [./nginx.conf:/etc/nginx/nginx.conf:ro, static:/app/staticfiles:ro]
    depends_on: [web]
volumes: {postgres_data:, static:}
```

## Nginx + SSL

```nginx
server {
    listen 443 ssl http2;
    server_name example.com;
    ssl_certificate /etc/letsencrypt/live/example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/example.com/privkey.pem;
    
    location /static/ { alias /app/staticfiles/; expires 30d; }
    location /media/ { alias /app/media/; }
    location / { proxy_pass http://web:8000; proxy_set_header Host $host; }
}
```

## Backup Database

```bash
#!/bin/bash
DATE=$(date +%Y%m%d)
pg_dump -U postgres clubcms | gzip > /var/backups/db_$DATE.sql.gz
find /var/backups -name "db_*.sql.gz" -mtime +30 -delete
```

## Health Check

```python
# apps/core/views.py
from django.http import JsonResponse
def health_check(request): return JsonResponse({"status": "ok"})
# urls.py: path("health/", health_check)
```

## Cache Redis (opzionale)

```python
CACHES = {"default": {
    "BACKEND": "django.core.cache.backends.redis.RedisCache",
    "LOCATION": "redis://127.0.0.1:6379"
}}
```
