# Hero Blocks

## HeroSliderBlock

```python
class HeroSlideBlock(blocks.StructBlock):
    image = ImageChooserBlock()
    title = blocks.CharBlock(max_length=100)
    subtitle = blocks.CharBlock(max_length=200, required=False)
    link = blocks.URLBlock(required=False)

class HeroSliderBlock(blocks.StructBlock):
    slides = blocks.ListBlock(HeroSlideBlock(), min_num=1, max_num=10)
    autoplay = blocks.BooleanBlock(default=True, required=False)
    interval = blocks.IntegerBlock(default=5000)
    height = blocks.ChoiceBlock(choices=[("50vh","50%"),("75vh","75%"),("100vh","100%")], default="75vh")
    class Meta:
        icon = "image"
        template = "website/blocks/hero_slider_block.html"
```

## HeroBannerBlock

```python
class HeroBannerBlock(blocks.StructBlock):
    image = ImageChooserBlock()
    title = blocks.CharBlock(max_length=100)
    subtitle = blocks.TextBlock(required=False)
    cta_text = blocks.CharBlock(max_length=50, required=False)
    cta_link = blocks.URLBlock(required=False)
    overlay_opacity = blocks.ChoiceBlock(choices=[("0","No"),("50","Medio"),("70","Scuro")], default="50")
    class Meta:
        icon = "doc-full"
        template = "website/blocks/hero_banner_block.html"
```

## HeroCountdownBlock

```python
class HeroCountdownBlock(blocks.StructBlock):
    event = blocks.PageChooserBlock(page_type="website.EventDetailPage")
    background_image = ImageChooserBlock(required=False)
    class Meta:
        icon = "date"
        template = "website/blocks/hero_countdown_block.html"
```

## Template Slider

```html
<section class="hero-slider" style="height:{{ self.height }}">
  {% for slide in self.slides %}
  {% image slide.image fill-1920x1080 as img %}
  <div class="slide{% if forloop.first %} active{% endif %}">
    <img src="{{ img.url }}"><h2>{{ slide.title }}</h2>
  </div>
  {% endfor %}
</section>
```

## Registrazione

```python
HERO_BLOCKS = [("slider", HeroSliderBlock()), ("banner", HeroBannerBlock()), ("countdown", HeroCountdownBlock())]
```
