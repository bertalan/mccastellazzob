# Moderazione Contenuti

## ModeratableContent Mixin

```python
class ModeratableContent(models.Model):
    is_approved = models.BooleanField(default=False)
    approved_by = models.ForeignKey(User, null=True, on_delete=models.SET_NULL)
    approved_at = models.DateTimeField(null=True)
    
    class Meta:
        abstract = True
```

## Moderazione Foto

```python
class PendingImageManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(is_approved=False)

class CustomImage(AbstractImage, ModeratableContent):
    objects = models.Manager()
    pending = PendingImageManager()
```

## Admin ViewSet

```python
class ModerationViewSet(ModelViewSet):
    model = CustomImage
    icon = "warning"
    menu_label = "Da Moderare"
    list_display = ["title", "uploaded_by", "uploaded_at"]
    
    def get_queryset(self):
        return CustomImage.pending.all()

@hooks.register("register_admin_viewset")
def register_moderation(): return ModerationViewSet("moderation")
```

## Quick Actions

```python
@require_POST
@permission_required("website.approve_content")
def approve_content(request, content_type, pk):
    model = {"image": CustomImage, "comment": Comment}[content_type]
    obj = get_object_or_404(model, pk=pk)
    obj.is_approved = True
    obj.approved_by = request.user
    obj.approved_at = timezone.now()
    obj.save()
    return JsonResponse({"ok": True})

@require_POST
@permission_required("website.reject_content")
def reject_content(request, content_type, pk):
    get_object_or_404(model, pk=pk).delete()
    return JsonResponse({"ok": True})
```

## Template Dashboard

```html
{% if pending_count %}
<div class="alert">{{ pending_count }} contenuti da moderare</div>
{% endif %}
```
