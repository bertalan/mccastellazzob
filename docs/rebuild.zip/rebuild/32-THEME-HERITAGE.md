# Theme: Heritage (Classic)

## Profile
| Aspect | Value |
|--------|-------|
| Framework | Bootstrap 5 (CSS only, no JS bundle) |
| Fonts | Playfair Display (heading), Lato (body) |
| Feel | Elegant, traditional, luxury |
| Bundle target | <80KB CSS |

## Palette (CSS Variables)
```
--primary: #1E3A5F (navy)   --secondary: #D4AF37 (gold)   --accent: #8B1538 (bordeaux)   --surface: #FDFCF7
```

## Component Guidelines

| Component | Style Notes |
|-----------|-------------|
| Hero | 70vh height, overlay badge, serif heading |
| Cards | 1px gold border, subtle hover shadow |
| Buttons | Rectangular, outline or fill variants |
| Grid | Bootstrap `.row .col-md-6 .col-lg-4` |
| Navbar | Dark navy, logo left, collapsible menu |

## Bootstrap Specifics
- Use CSS only (`bootstrap.min.css`), JS only if collapse/modal needed
- Override variables via `:root` CSS, not Sass (simpler build)
- Use spacing utilities `.py-5 .g-4` not custom CSS

## Files
```
templates/themes/heritage/{base,includes/{navbar,footer,hero}}.html
static/css/themes/heritage/{base,components}.css
```

## Wagtail Integration
Same as Velocity - theme switching via SiteSettings

## Performance Checklist
- [ ] Bootstrap CSS CDN or local (no unused components)
- [ ] Subset Google Fonts
- [ ] No Bootstrap JS unless needed
- [ ] `loading="lazy"` on images
