# Content Blocks

## CardBlock

```python
class CardBlock(blocks.StructBlock):
    image = ImageChooserBlock(required=False)
    title = blocks.CharBlock(max_length=100)
    text = blocks.TextBlock(required=False)
    link = blocks.URLBlock(required=False)
    class Meta:
        icon = "doc-full"
        template = "website/blocks/card_block.html"

class CardsGridBlock(blocks.StructBlock):
    cards = blocks.ListBlock(CardBlock(), max_num=12)
    columns = blocks.ChoiceBlock(choices=[("2","2"),("3","3"),("4","4")], default="3")
    class Meta:
        icon = "grip"
        template = "website/blocks/cards_grid_block.html"
```

## CTABlock

```python
class CTABlock(blocks.StructBlock):
    title = blocks.CharBlock(max_length=100)
    text = blocks.TextBlock(required=False)
    button_text = blocks.CharBlock(max_length=50)
    button_link = blocks.URLBlock()
    background = blocks.ChoiceBlock(choices=[("primary","Primary"),("dark","Dark")], default="primary")
    class Meta:
        icon = "pick"
        template = "website/blocks/cta_block.html"
```

## StatsBlock

```python
class StatItemBlock(blocks.StructBlock):
    icon = blocks.CharBlock(max_length=50, default="fas fa-star")
    value = blocks.CharBlock(max_length=20)
    label = blocks.CharBlock(max_length=50)

class StatsBlock(blocks.StructBlock):
    stats = blocks.ListBlock(StatItemBlock(), min_num=2, max_num=6)
    class Meta:
        icon = "order"
        template = "website/blocks/stats_block.html"
```

## QuoteBlock

```python
class QuoteBlock(blocks.StructBlock):
    quote = blocks.TextBlock()
    author = blocks.CharBlock(max_length=100, required=False)
    class Meta:
        icon = "openquote"
```

## TimelineBlock

```python
class TimelineItemBlock(blocks.StructBlock):
    year = blocks.CharBlock(max_length=10)
    title = blocks.CharBlock(max_length=100)
    description = blocks.TextBlock()

class TimelineBlock(blocks.StructBlock):
    items = blocks.ListBlock(TimelineItemBlock())
    class Meta:
        icon = "time"
        template = "website/blocks/timeline_block.html"
```

## Registrazione

```python
CONTENT_BLOCKS = [
    ("card", CardBlock()), ("cards_grid", CardsGridBlock()),
    ("cta", CTABlock()), ("stats", StatsBlock()), 
    ("quote", QuoteBlock()), ("timeline", TimelineBlock()),
]
```
