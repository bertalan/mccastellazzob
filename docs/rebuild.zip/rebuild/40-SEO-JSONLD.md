# SEO e JSON-LD

## JsonLdMixin

```python
import json

class JsonLdMixin:
    schema_type = "WebPage"
    
    def get_json_ld_data(self):
        return {"@type": self.schema_type, "name": self.title, "url": self.full_url}
    
    def get_json_ld(self):
        data = {"@context": "https://schema.org", **self.get_json_ld_data()}
        return json.dumps(data, ensure_ascii=False, default=str)
```

## Organization Data

```python
def get_organization_data(page):
    from apps.website.models import SiteSettings
    settings = SiteSettings.for_request(page.get_site())
    return {
        "name": settings.site_name,
        "url": page.get_site().root_url,
        "logo": settings.logo.get_rendition("original").url if settings.logo else None,
        "telephone": settings.phone,
    }
```

## Schema per Tipo

### HomePage → Organization
```python
def get_json_ld_data(self):
    return {"@type": "Organization", **get_organization_data(self)}
```

### NewsPage → Article
```python
def get_json_ld_data(self):
    return {
        "@type": "Article", "headline": self.title,
        "datePublished": self.first_published_at.isoformat(),
        "image": self.cover_image.get_rendition("width-1200").url,
    }
```

### EventPage → Event
```python
def get_json_ld_data(self):
    return {
        "@type": "Event", "name": self.title,
        "startDate": self.start_date.isoformat(),
        "location": {"@type": "Place", "name": self.location_name}
    }
```

## Template

```html
<head>
  {% if page.get_json_ld %}
  <script type="application/ld+json">{{ page.get_json_ld|safe }}</script>
  {% endif %}
</head>
```

## Validazione

https://search.google.com/test/rich-results
