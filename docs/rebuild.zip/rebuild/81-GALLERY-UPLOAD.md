# Gallery - Upload Soci

## CustomImage

```python
from wagtail.images.models import AbstractImage, AbstractRendition

class CustomImage(AbstractImage):
    uploaded_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL)
    is_approved = models.BooleanField(default=False)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    event = models.ForeignKey("website.EventDetailPage", null=True, blank=True, on_delete=models.SET_NULL)
    admin_form_fields = Image.admin_form_fields + ("uploaded_by", "is_approved", "event")

class CustomRendition(AbstractRendition):
    image = models.ForeignKey(CustomImage, on_delete=models.CASCADE, related_name="renditions")
```

## Settings

```python
WAGTAILIMAGES_IMAGE_MODEL = "website.CustomImage"
```

## View Upload

```python
@login_required
@require_POST
def upload_gallery_photo(request):
    form = PhotoUploadForm(request.POST, request.FILES)
    if form.is_valid():
        image = CustomImage.objects.create(
            file=form.cleaned_data["photo"],
            title=form.cleaned_data.get("title", ""),
            uploaded_by=request.user,
            event=form.cleaned_data.get("event"),
            collection=get_collection_for_user(request.user),
            is_approved=False
        )
        messages.success(request, "Foto caricata! In attesa di approvazione.")
    return redirect("gallery")
```

## Form

```python
class PhotoUploadForm(forms.Form):
    photo = forms.ImageField()
    title = forms.CharField(max_length=100, required=False)
    event = forms.ModelChoiceField(queryset=EventDetailPage.objects.live(), required=False)
```

## Template Upload

```html
{% if user.is_authenticated and user.profile.can_upload %}
<form method="post" action="{% url 'upload_photo' %}" enctype="multipart/form-data">
  {% csrf_token %}
  <input type="file" name="photo" accept="image/*" required>
  <input type="text" name="title" placeholder="Titolo">
  <button type="submit">Carica</button>
</form>
{% endif %}
```

## Approvazione (ModelViewSet)

```python
class PendingImagesViewSet(ModelViewSet):
    model = CustomImage
    icon = "image"
    menu_label = "Foto da approvare"
    list_display = ["title", "uploaded_by", "uploaded_at"]
    list_filter = {"is_approved": False}
```

## API Quick Approve

```python
@require_POST
@permission_required("website.approve_image")
def approve_image(request, image_id):
    CustomImage.objects.filter(id=image_id).update(is_approved=True)
    return JsonResponse({"ok": True})
```
