# StreamField Blocks

## Architettura

```python
# apps/website/blocks/__init__.py
from .base import *
from .hero import *
from .content import *
from .media import *
from .layout import *

CONTENT_BLOCKS = HERO_BLOCKS + CONTENT_BLOCKS + MEDIA_BLOCKS + LAYOUT_BLOCKS
```

## BaseBlock

```python
class BaseBlock(blocks.StructBlock):
    settings = SettingsBlock()
    class Meta:
        abstract = True
```

## SettingsBlock

```python
class SettingsBlock(blocks.StructBlock):
    custom_id = blocks.CharBlock(max_length=50, required=False)
    custom_class = blocks.CharBlock(max_length=100, required=False)
    background = blocks.ChoiceBlock(choices=[("","Default"),("light","Light"),("dark","Dark")], required=False)
    padding = blocks.ChoiceBlock(choices=[("sm","S"),("md","M"),("lg","L")], default="md")
```

## Categorie Blocks

| Categoria | Blocks | File |
|-----------|--------|------|
| Hero | HeroSliderBlock, HeroBannerBlock | 21-HERO-BLOCKS.md |
| Content | CardBlock, CTABlock, StatsBlock | 22-CONTENT-BLOCKS.md |
| Media | GalleryBlock, VideoEmbedBlock | 23-MEDIA-BLOCKS.md |
| Layout | GridBlock, AccordionBlock | 24-LAYOUT-BLOCKS.md |

## Template Block

```html
<section class="cta {{ self.settings.background }} py-{{ self.settings.padding }}"
         {% if self.settings.custom_id %}id="{{ self.settings.custom_id }}"{% endif %}>
  <h2>{{ self.title }}</h2>
  <a href="{{ self.button_link }}" class="btn">{{ self.button_text }}</a>
</section>
```

## Uso in Page

```python
body = StreamField(CONTENT_BLOCKS, use_json_field=True, blank=True)
```
