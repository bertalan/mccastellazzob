# HomePage Model

## Campi

```python
class HomePage(JsonLdMixin, Page):
    schema_type = "Organization"
    max_count = 1
    
    hero_title = models.CharField(max_length=100)
    hero_subtitle = models.CharField(max_length=200, blank=True)
    hero_image = models.ForeignKey("wagtailimages.Image", null=True, on_delete=models.SET_NULL)
    featured_event = models.ForeignKey("EventDetailPage", null=True, blank=True, on_delete=models.SET_NULL)
    
    body = StreamField([
        ("hero_slider", HeroSliderBlock()),
        ("stats", StatsBlock()),
        ("featured_news", FeaturedNewsBlock()),
        ("cta", CTABlock()),
        ("gallery_preview", GalleryPreviewBlock()),
    ], use_json_field=True)
    
    content_panels = Page.content_panels + [
        MultiFieldPanel([
            FieldPanel("hero_title"), FieldPanel("hero_subtitle"), FieldPanel("hero_image"),
        ], heading="Hero"),
        FieldPanel("featured_event"),
        FieldPanel("body"),
    ]
```

## JSON-LD

```python
def get_json_ld_data(self):
    org = get_organization_data(self)
    return {"@type": "Organization", "name": org["name"], "url": self.full_url, "logo": org["logo"]}
```

## Template

```html
{% extends "base.html" %}
{% block content %}
  {% for block in page.body %}{% include_block block %}{% endfor %}
  {% if page.featured_event %}
    {% include "website/includes/featured_event.html" %}
  {% endif %}
{% endblock %}
```

## Differenze da Attuale

| Attuale | Nuovo |
|---------|-------|
| hero_carousel FK | StreamField hero_slider |
| simple_carousel snippet | Inline StreamField |
| Campi hero duplicati | StreamField flessibile |
