# Page Models Base

## JsonLdMixin

```python
# apps/core/seo.py
class JsonLdMixin:
    """Mixin per JSON-LD schema.org."""
    schema_type = "WebPage"
    
    def get_json_ld_data(self):
        return {"@type": self.schema_type, "name": self.title, "url": self.full_url}
    
    def get_json_ld(self):
        return {"@context": "https://schema.org", **self.get_json_ld_data()}
```

## BasePage

```python
# apps/website/models/pages.py
from wagtail.models import Page
from wagtail.fields import StreamField
from apps.core.seo import JsonLdMixin
from .blocks import CONTENT_BLOCKS

class BasePage(JsonLdMixin, Page):
    """Classe base astratta."""
    class Meta:
        abstract = True
    
    body = StreamField(CONTENT_BLOCKS, blank=True, use_json_field=True)
```

## Gerarchia

```
Root
├── HomePage (max 1)
├── AboutPage → BoardPage
├── NewsIndexPage → NewsPage
├── EventsPage → EventDetailPage
├── GalleryPage
├── ContactPage
└── PrivacyPage
```

## Block Registry

```python
# apps/website/blocks/__init__.py
from wagtail import blocks
from .hero import HeroSliderBlock
from .content import CardBlock, CTABlock
from .media import GalleryBlock

CONTENT_BLOCKS = [
    ("hero_slider", HeroSliderBlock()),
    ("cards", blocks.ListBlock(CardBlock())),
    ("cta", CTABlock()),
    ("gallery", GalleryBlock()),
    ("rich_text", blocks.RichTextBlock()),
]
```

## Template Convention

Wagtail cerca: `templates/website/{app}_{model}.html`

```python
class HomePage(Page):
    template = "website/pages/home_page.html"
```

## Campi Consigliati

| Campo | Tipo | Uso |
|-------|------|-----|
| `intro` | CharField | Sottotitolo |
| `cover_image` | ForeignKey(Image) | Header |
| `body` | StreamField | Contenuto |
| `tags` | ClusterTaggableManager | Tag |

## Promote Panels

```python
Page.promote_panels + [FieldPanel("search_image")]
```

Vedi [40-SEO-JSONLD.md](40-SEO-JSONLD.md) per JSON-LD completo.
