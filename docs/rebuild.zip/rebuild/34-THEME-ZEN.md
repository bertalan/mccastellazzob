# Theme: Zen (Minimalism with Purpose)

## Profile
| Aspect | Value |
|--------|-------|
| Framework | Pure CSS (no framework) |
| Fonts | Inter only (one font, 2 weights) |
| Feel | Focused, content-first, calm |
| Bundle target | <10KB CSS total |

## Palette (CSS Variables)
```
--ink: #111   --paper: #FFF   --mist: #F5F5F5   --accent: #0066FF
```

## Design Rules

| Rule | Rationale |
|------|-----------|
| Max 3 nav items | Reduce decision fatigue |
| 1 CTA per section | Clear action hierarchy |
| Max 720px content width | Optimal reading line length |
| No carousels | Users don't engage with them |
| No decorative images | Every image must inform |
| Text links > Buttons | Minimal visual noise |

## Component Guidelines

| Component | Style Notes |
|-----------|-------------|
| Hero | Text-only, massive typography, no image |
| Cards | No borders, spacing-defined, minimal |
| Buttons | Underlined links, not boxes |
| Grid | 2 columns max, asymmetric (2fr 1fr) |
| Footer | Single line, essential links only |

## Typography Scale
```css
h1: clamp(2.5rem, 8vw, 5rem)
h2: 1.5rem
body: 1rem
small: 0.85rem
```

## Files
```
templates/themes/zen/{base,includes/{navbar,footer}}.html
static/css/themes/zen/main.css  /* single file */
```

## Anti-Patterns (Never Use)
- Parallax, animations, decorative icons
- Multiple button styles
- Sidebar content
- Auto-playing media
