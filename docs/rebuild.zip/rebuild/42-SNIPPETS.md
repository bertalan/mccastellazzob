# Snippets

## Definizione

**Snippet** = contenuto riutilizzabile gestito da editor CMS.

✅ **Usare Snippet per**: Navbar, Footer, ColorScheme, Categorie, FAQ, Partner
❌ **NON Snippet**: Dati transazionali, iscrizioni, commenti (→ Django Model)

## Navbar

```python
from wagtail.snippets.models import register_snippet
from wagtail.models import TranslatableMixin, Orderable
from modelcluster.models import ClusterableModel, ParentalKey

@register_snippet
class Navbar(TranslatableMixin, ClusterableModel):
    name = models.CharField(max_length=50)
    panels = [FieldPanel("name"), InlinePanel("items", label="Voci")]

class NavbarItem(Orderable):
    navbar = ParentalKey(Navbar, related_name="items")
    title = models.CharField(max_length=50)
    link_page = models.ForeignKey(Page, null=True, blank=True, on_delete=models.SET_NULL)
    link_url = models.URLField(blank=True)
    
    @property
    def url(self):
        return self.link_page.url if self.link_page else self.link_url
```

## Footer

```python
@register_snippet
class Footer(TranslatableMixin, models.Model):
    name = models.CharField(max_length=50)
    description = models.TextField(blank=True)
    facebook = models.URLField(blank=True)
    instagram = models.URLField(blank=True)
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=20, blank=True)
```

## ColorScheme

See [37-COLOR-SCHEME.md](37-COLOR-SCHEME.md) for dynamic color system.

## SiteSettings

```python
from wagtail.contrib.settings.models import BaseSiteSetting, register_setting

@register_setting
class SiteSettings(BaseSiteSetting):
    site_name = models.CharField(max_length=100)
    logo = models.ForeignKey("wagtailimages.Image", null=True, on_delete=models.SET_NULL)
    navbar = models.ForeignKey(Navbar, null=True, on_delete=models.SET_NULL)
    footer = models.ForeignKey(Footer, null=True, on_delete=models.SET_NULL)
    color_scheme = models.ForeignKey("ColorScheme", null=True, on_delete=models.SET_NULL)
```

## Template

```django
{% load wagtailsettings_tags %}
{% get_settings %}

{% for item in settings.website.SiteSettings.navbar.items.all %}
    <a href="{{ item.url }}">{{ item.title }}</a>
{% endfor %}
```

## SnippetViewSet (Wagtail 7+)

```python
from wagtail.snippets.views.snippets import SnippetViewSet

class NavbarViewSet(SnippetViewSet):
    model = Navbar
    icon = "list-ul"
    menu_label = "Navigazione"
    list_display = ["name"]
```

## References

- Navbar/Footer: this document
- ColorScheme: [37-COLOR-SCHEME.md](37-COLOR-SCHEME.md)
- Transactional models: [83-MODELS-TRANSAZIONALI.md](83-MODELS-TRANSAZIONALI.md)
