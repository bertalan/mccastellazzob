# News & Events

## Struttura

`NewsIndexPage → NewsPage` | `EventsPage → EventDetailPage`

## NewsIndexPage

```python
class NewsIndexPage(JsonLdMixin, Page):
    subpage_types = ["website.NewsPage"]
    max_count = 1
    intro = models.CharField(max_length=255, blank=True)
    
    def get_context(self, request):
        context = super().get_context(request)
        articles = NewsPage.objects.live().descendant_of(self).order_by("-date_display")
        if tag := request.GET.get("tag"):
            articles = articles.filter(tags__name=tag)
        context["articles"] = Paginator(articles, 12).get_page(request.GET.get("page", 1))
        return context
```

## NewsPage

```python
class NewsPage(JsonLdMixin, Page):
    schema_type = "Article"
    parent_page_types = ["website.NewsIndexPage"]
    
    date_display = models.DateField(default=timezone.now)
    author = models.ForeignKey(User, null=True, on_delete=models.SET_NULL)
    cover_image = models.ForeignKey("wagtailimages.Image", null=True, on_delete=models.SET_NULL)
    intro = models.CharField(max_length=255, blank=True)
    body = StreamField(CONTENT_BLOCKS, use_json_field=True)
    tags = ClusterTaggableManager(through=NewsPageTag, blank=True)
```

## EventsPage

```python
class EventsPage(JsonLdMixin, Page):
    subpage_types = ["website.EventDetailPage"]
    
    def get_context(self, request):
        context = super().get_context(request)
        context["events"] = EventDetailPage.objects.live().filter(start_date__gte=timezone.now()).order_by("start_date")
        return context
```

## EventDetailPage

```python
class EventDetailPage(JsonLdMixin, Page):
    schema_type = "Event"
    parent_page_types = ["website.EventsPage"]
    
    start_date = models.DateTimeField()
    end_date = models.DateTimeField(null=True, blank=True)
    location_name = models.CharField(max_length=255)
    location_address = models.TextField(blank=True)
    image = models.ForeignKey("wagtailimages.Image", null=True, on_delete=models.SET_NULL)
    body = StreamField(CONTENT_BLOCKS, use_json_field=True)
    registration_open = models.BooleanField(default=False)
    max_participants = models.PositiveIntegerField(default=0)
    
    @property
    def is_past(self): return self.start_date < timezone.now()
```

## Tags

```python
class NewsPageTag(TaggedItemBase):
    content_object = ParentalKey("NewsPage", related_name="tagged_items")
```

Vedi [82-EVENTI-ISCRIZIONI.md](82-EVENTI-ISCRIZIONI.md) per iscrizioni.
