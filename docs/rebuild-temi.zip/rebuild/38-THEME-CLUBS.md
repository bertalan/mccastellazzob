# Theme 5: Clubs

Tema premium ispirato ai brand motociclistici italiani. Design elegante, storytelling immersivo, sezioni full-width con transizioni fluide.

## Profilo

| Attributo | Valore |
|-----------|--------|
| Target | Club motociclistici, associazioni automotive, community premium |
| Stack | Tailwind CSS |
| Budget | <60KB |
| Stile | Premium italiano, hero immersivi, tipografia bold |

## Palette Colori (WCAG AA)

```css
:root {
  --clubs-black: #0A0A0A;        /* Sfondo principale */
  --clubs-dark: #1A1A1A;         /* Navbar, cards */
  --clubs-white: #FFFFFF;        /* Testo primario */
  --clubs-gray: #A0A0A0;         /* Testo secondario - contrasto 7:1 */
  --clubs-red: #C41E3A;          /* Accent - rosso italiano */
  --clubs-red-hover: #E02547;    /* Hover state */
}
```

## Tipografia

- **Headings**: `font-weight: 900`, uppercase, letter-spacing tight
- **Body**: Sistema fonts, peso 400, line-height 1.7
- **CTA**: Bold, uppercase, spaziatura larga

## Componenti Distintivi

### Navbar
- Fixed top, background nero con blur
- Logo bianco a sinistra
- Menu items uppercase, hover con underline animato
- CTA button rosso a destra

### Hero Sections
- Full viewport height
- Immagine/video di sfondo con overlay gradient
- Titolo centrato, font-weight 900
- Sottotitolo con opacità ridotta
- CTA buttons prominenti

### Content Sections
- Alternanza nero/grigio scuro
- Padding generoso (6rem+)
- Titoli sezione uppercase con linea decorativa
- Cards con hover effect (scale + shadow)

### Footer
- Background nero
- Logo grande centrato
- Link organizzati in colonne
- Social icons prominenti
- Copyright con branding

## Pattern Wagtail

```python
# In SiteSettings
class ThemeSettings(BaseSiteSetting):
    theme = models.CharField(
        max_length=20,
        choices=[
            ('velocity', 'Velocity'),
            ('heritage', 'Heritage'),
            ('terra', 'Terra'),
            ('zen', 'Zen'),
            ('clubs', 'Clubs'),  # Nuovo tema
        ],
        default='velocity'
    )
```

## Elementi Specifici

1. **Sezioni Storia/Tradizione**: Timeline verticale con date prominenti
2. **Gallery**: Grid con hover zoom + overlay info
3. **News/Eventi**: Cards orizzontali con data in evidenza
4. **Servizi**: Grid 3 colonne con icone/numeri
5. **CTA Sections**: Background rosso, testo bianco, effetto immersivo

## Anti-patterns

- ❌ Colori pastello
- ❌ Font serif
- ❌ Bordi arrotondati eccessivi (max 4px)
- ❌ Elementi infantili o casual
- ❌ Troppo spazio bianco

## File Demo

Vedi `examples/clubs/` per le 5 pagine navigabili.
