# Theme Demo Examples

6 temi navigabili con 5 pagine ciascuno. Nessuna dipendenza esterna obbligatoria.

## Struttura

```
examples/
├── velocity/    # Tailwind CSS - Moderno/Dinamico
├── heritage/    # Bootstrap 5 - Classico/Elegante  
├── terra/       # Pure CSS - Eco-friendly con "Biker Boost"
├── zen/         # Pure CSS - Comic/Manga Style
├── clubs/       # Tailwind CSS - Premium Motorsport
└── tricolore/   # Pure CSS - Omaggio all'Italia 🇮🇹
```

## Pagine per Tema

| Pagina | Descrizione |
|--------|-------------|
| `index.html` | Home con hero, stats, eventi |
| `about.html` | Chi siamo, valori, team |
| `events.html` | Lista eventi/itinerari |
| `gallery.html` | Galleria immagini/simboli |
| `contact.html` | Form contatto + info |

## Caratteristiche per Tema

### Velocity
- **Stack**: Tailwind CDN + Google Fonts (Inter, Open Sans)
- **Brand**: "ClubHub"
- **Palette**: Amber/Slate
- **Stile**: Cards arrotondate, blur navbar, pill buttons

### Heritage
- **Stack**: Bootstrap 5 + Google Fonts (Playfair Display, Lato)
- **Brand**: "The Society"
- **Palette**: Navy (#1a2744) / Gold (#D4A520)
- **Stile**: Bordi dorati, footer dark, badge eleganti

### Terra
- **Stack**: Pure CSS + Google Fonts (Montserrat)
- **Brand**: "GreenOrg"
- **Palette**: Forest (#2D5016) / Earth (#6B3410) / Accent (#E85D04 "sunset road")
- **Stile**: Diagonal hero clip-path, racing stripe cards, micro-animazioni hover

### Zen
- **Stack**: Pure CSS + System fonts
- **Brand**: "Mindful"
- **Palette**: Ink (#0A0A0A) / Paper (#FFFFFF) + Pop colors (Magenta, Yellow, Blue, Green)
- **Stile**: Comic/Manga panels, halftone patterns, speed lines, speech bubbles, color pop

### Clubs
- **Stack**: Tailwind CDN + System fonts
- **Brand**: "EagleRiders"
- **Palette**: Black (#0A0A0A) / Red (#C41E3A)
- **Stile**: Full-height hero, uppercase headings, border cards, Italian motorsport aesthetic

### Tricolore 🇮🇹
- **Stack**: Pure CSS + Google Fonts (Montserrat)
- **Brand**: "MotoItalia"
- **Palette**: Verde (#009246) / Bianco (#F4F5F0) / Rosso (#CE2B37) / Oro (#C9A227)
- **Stile**: Tricolore ribbons, coccarde decorative, badge con gradiente, hover translateX
- **Target**: Mototuristi innamorati dell'Italia
- **Contenuti**: Itinerari iconici (Stelvio, Amalfi, Chianti, Etna, Motor Valley)

## Test Locale

```bash
cd examples/velocity
python -m http.server 8000
# Aprire http://localhost:8000
```

## Note Wagtail Integration

Questi HTML sono prototipi statici. In Wagtail:
- Navbar → `NavigationSettings` snippet
- Hero → `HeroBlock` con `get_template()`
- Cards → `CardBlock` con template per tema
- Footer → `FooterSettings` snippet

Vedi [35-THEMES-PROPOSAL.md](../35-THEMES-PROPOSAL.md) per l'implementazione.
