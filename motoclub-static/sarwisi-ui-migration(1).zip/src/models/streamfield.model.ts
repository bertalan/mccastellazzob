export type BlockType = 'hero' | 'features' | 'content' | 'cta' | 'testimonials' | 'timeline';

export interface BaseBlock<T> {
  id: string;
  type: BlockType;
  value: T;
}

export interface HeroData {
  title: string;
  subtitle: string;
  ctaText: string;
  ctaLink: string;
  backgroundImage?: string;
}

export interface FeatureItem {
  icon: string;
  title: string;
  description: string;
}

export interface FeaturesData {
  title: string;
  items: FeatureItem[];
}

export interface ContentData {
  heading: string;
  body: string; // HTML string simulation
  alignment: 'left' | 'center' | 'right';
}

export interface CtaData {
  title: string;
  description: string;
  buttonText: string;
  buttonLink: string;
  theme: 'primary' | 'dark';
}

export interface TestimonialItem {
  quote: string;
  author: string;
  role: string;
  avatar: string;
}

export interface TestimonialsData {
  title: string;
  items: TestimonialItem[];
}

export interface TimelineItem {
  year: string;
  title: string;
  description: string;
}

export interface TimelineData {
  title: string;
  description?: string;
  items: TimelineItem[];
}

export type PageBlock = 
  | BaseBlock<HeroData> 
  | BaseBlock<FeaturesData> 
  | BaseBlock<ContentData> 
  | BaseBlock<CtaData>
  | BaseBlock<TestimonialsData>
  | BaseBlock<TimelineData>;
