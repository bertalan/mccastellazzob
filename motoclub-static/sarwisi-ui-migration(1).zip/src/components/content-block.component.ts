import { Component, input, computed, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContentData } from '../models/streamfield.model';
import { ScrollAnimationDirective } from '../directives/scroll-animation.directive';

@Component({
  selector: 'app-content-block',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ScrollAnimationDirective],
  template: `
    <section class="py-16 bg-white">
      <div class="container mx-auto px-6">
        <div [class]="containerClasses()" appScrollAnimation>
          @if (data().heading) {
            <h2 class="text-3xl font-bold text-gray-800 mb-6">{{ data().heading }}</h2>
          }
          <div class="prose prose-lg text-gray-600 max-w-none">
            {{ data().body }}
          </div>
        </div>
      </div>
    </section>
  `
})
export class ContentBlockComponent {
  data = input.required<ContentData>();

  containerClasses = computed(() => {
    const align = this.data().alignment;
    switch (align) {
      case 'center': return 'max-w-3xl mx-auto text-center';
      case 'right': return 'max-w-3xl ml-auto text-right';
      default: return 'max-w-3xl mr-auto text-left';
    }
  });
}