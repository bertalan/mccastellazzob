import { Injectable } from '@angular/core';
import { PageBlock } from '../models/streamfield.model';
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PageContentService {

  // Simulating a Wagtail Page API response with StreamField data
  getPageData() {
    const blocks: PageBlock[] = [
      {
        id: 'b1',
        type: 'hero',
        value: {
          title: 'Gestione Semplificata per il Tuo Business',
          subtitle: 'La piattaforma Sarwisi ti aiuta a organizzare, monitorare e far crescere la tua attività con strumenti digitali all\'avanguardia.',
          ctaText: 'Inizia Gratuitamente',
          ctaLink: '#start',
          backgroundImage: 'https://picsum.photos/1920/1080?blur=2'
        } as any
      },
      {
        id: 'b2',
        type: 'features',
        value: {
          title: 'I Nostri Servizi',
          items: [
            { icon: 'fa-chart-line', title: 'Analisi Dati', description: 'Monitora le performance in tempo reale con dashboard intuitive.' },
            { icon: 'fa-users', title: 'Gestione Team', description: 'Coordina il tuo team e assegna task con facilità.' },
            { icon: 'fa-shield-alt', title: 'Sicurezza Avanzata', description: 'I tuoi dati sono protetti con crittografia end-to-end.' },
            { icon: 'fa-rocket', title: 'Automazione', description: 'Risparmia tempo automatizzando i processi ripetitivi.' }
          ]
        } as any
      },
      {
        id: 'timeline1',
        type: 'timeline',
        value: {
          title: 'La Nostra Storia',
          description: 'Dalla prima riga di codice all\'espansione globale. Ecco come siamo arrivati qui.',
          items: [
            { year: '2020', title: 'La Fondazione', description: 'Sarwisi nasce in un piccolo garage a Milano con l\'idea di semplificare la burocrazia digitale per le PMI.' },
            { year: '2021', title: 'Il Lancio della Beta', description: 'Dopo mesi di sviluppo, lanciamo la prima versione per 50 aziende pilota. Il feedback è entusiasmante.' },
            { year: '2022', title: 'Espansione Nazionale', description: 'Raggiungiamo 1000 clienti in tutta Italia e apriamo il nostro primo ufficio fisico.' },
            { year: '2023', title: 'Serie A Funding', description: 'Raccogliamo 5 milioni di euro per investire in AI e automazione, raddoppiando il team tecnico.' },
            { year: '2024', title: 'Sarwisi Global', description: 'Inizia l\'espansione verso i mercati europei con localizzazione in 4 lingue.' }
          ]
        } as any
      },
      {
        id: 'b3',
        type: 'content',
        value: {
          heading: 'Perché Scegliere Sarwisi?',
          body: 'Siamo impegnati a fornire soluzioni tecnologiche che non solo risolvono problemi, ma creano opportunità. La nostra architettura modulare permette di scalare le funzionalità in base alla crescita del tuo business, garantendo sempre la massima efficienza.',
          alignment: 'center'
        } as any
      },
      {
        id: 'b4',
        type: 'testimonials',
        value: {
          title: 'Dicono di Noi',
          items: [
            { quote: 'Sarwisi ha trasformato il modo in cui gestiamo i nostri progetti. Indispensabile.', author: 'Marco Rossi', role: 'CEO, TechIt', avatar: 'https://picsum.photos/100/100?random=1' },
            { quote: 'Un supporto clienti eccezionale e una piattaforma solida. Consigliatissimo.', author: 'Giulia Bianchi', role: 'Ops Manager', avatar: 'https://picsum.photos/100/100?random=2' },
            { quote: 'La flessibilità dei moduli ci ha permesso di adattare il software alle nostre esigenze.', author: 'Luca Verdi', role: 'Freelance', avatar: 'https://picsum.photos/100/100?random=3' }
          ]
        } as any
      },
      {
        id: 'b5',
        type: 'cta',
        value: {
          title: 'Pronto a Scalare?',
          description: 'Unisciti a centinaia di aziende che hanno scelto l\'innovazione.',
          buttonText: 'Richiedi Demo',
          buttonLink: '#demo',
          theme: 'primary'
        } as any
      }
    ];

    return of(blocks);
  }
}
